# 🚀 INSTALAÇÃO WINDOWS - AI GAME FORGE PRO

## ⚡ Guia Rápido (3 minutos)

### 1️⃣ Extrair ZIP
```
- Clique direito no ZIP → Extrair Tudo
- Escolha uma pasta (ex: C:\Projects)
```

### 2️⃣ Abrir Terminal
```
- Pressione Win + R
- Digite: cmd
- Pressione Enter
```

### 3️⃣ Navegar até a pasta
```bash
cd C:\Projects\ai-game-forge-pro-v2
```

### 4️⃣ Instalar Dependências
```bash
npm install
```

**IMPORTANTE:** Ignore os warnings deprecados - são normais e não afetam o funcionamento!

### 5️⃣ Iniciar Aplicação
```bash
npm run dev
```

**Pronto!** O navegador abrirá automaticamente em `http://localhost:3000`

---

## 🔧 Possíveis Problemas

### ❌ "npm não é reconhecido"
**Solução:** Instale Node.js
1. Baixe: https://nodejs.org (versão LTS)
2. Instale com configurações padrão
3. Reinicie o terminal
4. Tente novamente

### ❌ Erro de permissão
**Solução:** Execute como Administrador
1. Clique direito no CMD
2. "Executar como administrador"
3. Tente novamente

### ❌ Porta 3000 em uso
**Solução:** Use outra porta
```bash
npm run dev -- --port 3001
```

---

## ✅ Configuração de API

### Groq (RECOMENDADO - Grátis)

1. **Criar conta:**
   - Acesse: https://console.groq.com
   - Clique "Sign Up"
   - Use Google/GitHub para login rápido

2. **Obter API Key:**
   - No dashboard, clique "API Keys"
   - Clique "Create API Key"
   - Copie a chave (começa com `gsk_`)

3. **Configurar no app:**
   - No AI Game Forge, clique ⚙️ Configurações
   - Encontre "Groq"
   - Cole a API key
   - Pronto!

### Outras APIs (Opcional)

**Para imagens (sem API key!):**
- Pollinations AI já funciona automaticamente

**Para busca web (sem API key!):**
- DuckDuckGo já funciona automaticamente

---

## 🎮 Primeiro Uso

1. **Nome do projeto:** Digite "MeuJogo"
2. **Linguagem:** Selecione "JavaScript"
3. **Framework:** Digite "Phaser"
4. **Tipo:** Selecione "Platformer"
5. **Ative:** ✅ Modo Colaborativo
6. **Descreva:** "Criar jogo de pong com placar"
7. **Clique:** 🤖 Gerar com Todas as IAs
8. **Aguarde:** ~30 segundos
9. **Vá para:** Tab ▶️ Player
10. **Clique:** Jogar

**Parabéns! Você criou seu primeiro jogo com IA! 🎉**

---

## 📞 Suporte

**Problemas?**
- Leia o README.md
- Consulte o GUIA_RAPIDO_PRO.md

**Dica:** A maioria dos problemas se resolve com:
```bash
# Limpar e reinstalar
rd /s /q node_modules
npm install
```

---

**Desenvolvido para Windows 10/11** ✅
