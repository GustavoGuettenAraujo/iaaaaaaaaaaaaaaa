# Como rodar o AI Game Forge PRO Localmente

Para rodar este projeto no seu computador, você precisará do **Node.js** instalado.

## Passos para Instalação

1. **Baixe e extraia o ZIP** do projeto.
2. **Abra o Terminal ou CMD** na pasta onde você extraiu os arquivos.
3. **Instale as dependências**:
   ```bash
   cd ai-game-forge-final
   npm install
   ```

## Como Executar

Você precisará de dois terminais abertos:

### Terminal 1: Servidor Backend (API)
```bash
cd ai-game-forge-final
node server/index.js
```
O servidor rodará em `http://localhost:3000`.

### Terminal 2: Interface Frontend (Vite)
```bash
cd ai-game-forge-final
npm run dev
```
O frontend rodará em `http://localhost:5000`.

## Configuração de APIs
Ao abrir o app no navegador, clique no botão **Configurações** para inserir suas chaves de API (Groq, Gemini, etc.). As chaves ficam salvas apenas no seu navegador (localStorage).
