import React, { useMemo, useState } from 'react';
import { FileText, Map, MessageSquare, Megaphone, Wand2, Bug, Zap, Globe, Palette, Code } from 'lucide-react';
import { AI_PROVIDERS } from '../config/aiConfig.js';
import collaborativeAIService from '../services/collaborativeAIService.js';

const TOOL_DEFS = [
  {
    id: 'gdd',
    icon: FileText,
    title: 'Game Design Doc (GDD)',
    buildPrompt: ({ description, gameType, framework, language }) => `
Voce e um game designer senior.
Crie um GDD completo (em portugues) para o jogo abaixo, com secoes:
- Elevator pitch
- Loop principal
- Mecanicas
- Progressao
- Inimigos/obstaculos
- Controles
- Arte e audio (direcao)
- Requisitos tecnicos
- Riscos e mitigacao
- Roadmap (MVP -> v1)
Jogo: ${description}
Tipo: ${gameType}
Framework: ${framework}
Linguagem: ${language}
Responda em Markdown.`
  },
  {
    id: 'levels',
    icon: Map,
    title: 'Ideias de fases/niveis',
    buildPrompt: ({ description, gameType }) => `
Gere 12 ideias de fases para um jogo do tipo ${gameType}.
Contexto do jogo: ${description}
Para cada fase inclua: objetivo, twist mecanico, e dificuldade (1-5).`
  },
  {
    id: 'dialogue',
    icon: MessageSquare,
    title: 'Dialogos e narrativa',
    buildPrompt: ({ description }) => `
Crie uma premissa narrativa + 10 falas curtas (1-2 linhas) para NPCs/feedback de jogo.
Contexto: ${description}
Tom: divertido e direto.`
  },
  {
    id: 'marketing',
    icon: Megaphone,
    title: 'Pagina de store / marketing',
    buildPrompt: ({ description, gameType }) => `
Crie um texto de pagina de loja (Steam/Itch) para o jogo:
- Titulo
- 3 bullets de features
- Descricao (120-180 palavras)
- Tags sugeridas
Jogo (${gameType}): ${description}`
  },
  {
    id: 'debug',
    icon: Bug,
    title: 'Debug e Correcao',
    buildPrompt: ({ description, framework, language }) => `
Voce e um especialista em debugging de jogos.
Analise o seguinte contexto e liste:
1. Possiveis bugs comuns para esse tipo de jogo
2. Solucoes para cada bug
3. Boas praticas de prevenção

Contexto do jogo: ${description}
Framework: ${framework}
Linguagem: ${language}

Seja especifico e pratico.`
  },
  {
    id: 'optimize',
    icon: Zap,
    title: 'Otimizacao de Performance',
    buildPrompt: ({ description, framework, language }) => `
Voce e um especialista em otimizacao de jogos.
Sugira otimizacoes para:

Contexto: ${description}
Framework: ${framework}
Linguagem: ${language}

Inclua:
1. Otimizacoes de rendering
2. Otimizacoes de memoria
3. Otimizacoes de logica
4. Boas praticas de loading
5. Dicas de bundle size`
  },
  {
    id: 'translate',
    icon: Globe,
    title: 'Traducao e i18n',
    buildPrompt: ({ description, gameType }) => `
Crie um guia de internacionalizacao para o jogo:

Jogo: ${description}
Tipo: ${gameType}

Inclua:
1. Lista de strings para traduzir (UI, dialogos, tutoriais)
2. Estrutura de arquivos JSON para i18n
3. Dicas de localizacao (formatos de data, moeda, etc)
4. Strings de exemplo em PT-BR, EN, ES`
  },
  {
    id: 'art',
    icon: Palette,
    title: 'Guia de Arte',
    buildPrompt: ({ description, gameType, framework }) => `
Crie um guia de direcao de arte para o jogo:

Jogo: ${description}
Tipo: ${gameType}
Framework: ${framework}

Inclua:
1. Paleta de cores (hex codes)
2. Estilo visual recomendado
3. Referencias visuais
4. Especificacoes de sprites/assets
5. Dicas de animacao`
  },
  {
    id: 'refactor',
    icon: Code,
    title: 'Refatoracao de Codigo',
    buildPrompt: ({ description, framework, language }) => `
Voce e um arquiteto de software de jogos.
Sugira uma arquitetura limpa para:

Contexto: ${description}
Framework: ${framework}
Linguagem: ${language}

Inclua:
1. Estrutura de pastas recomendada
2. Padroes de design aplicaveis
3. Separacao de responsabilidades
4. Sistema de componentes/entidades
5. Exemplo de codigo refatorado`
  }
];

export default function AIAssistants({
  description,
  gameType,
  framework,
  language,
  apiKeys
}) {
  const [provider, setProvider] = useState('GROQ');
  const [toolId, setToolId] = useState('gdd');
  const [output, setOutput] = useState('');
  const [isRunning, setIsRunning] = useState(false);
  const [error, setError] = useState('');

  const availableProviders = useMemo(() => {
    return Object.entries(AI_PROVIDERS)
      .filter(([id, p]) => p.type === 'code')
      .map(([id, p]) => ({ id, name: p.name, hasKey: !!apiKeys?.[id], free: !!p.free }));
  }, [apiKeys]);

  const run = async () => {
    setError('');
    setOutput('');
    if (!description?.trim()) {
      setError('Descreva o jogo no campo de prompt antes de usar os assistentes.');
      return;
    }
    if (!apiKeys?.[provider]) {
      setError(`Defina uma API key para ${provider} em Configuracoes.`);
      return;
    }

    const tool = TOOL_DEFS.find(t => t.id === toolId);
    const prompt = tool.buildPrompt({ description, gameType, framework, language });

    setIsRunning(true);
    try {
      const text = await collaborativeAIService.callAI(provider, prompt, { maxTokens: 3000, temperature: 0.6 });
      setOutput(text || '(sem resposta)');
    } catch (e) {
      setError(e?.message || String(e));
    } finally {
      setIsRunning(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(output);
    alert('Copiado para a area de transferencia!');
  };

  return (
    <div className="assistants">
      <div className="assistants-header">
        <h2>Assistentes IA</h2>
        <p className="muted">Gere documentos, analises e ideias usando IAs especializadas.</p>
      </div>

      <div className="assistants-tools-grid">
        {TOOL_DEFS.map(tool => {
          const Icon = tool.icon;
          return (
            <button
              key={tool.id}
              className={`tool-card ${toolId === tool.id ? 'active' : ''}`}
              onClick={() => setToolId(tool.id)}
            >
              <Icon size={24} />
              <span>{tool.title}</span>
            </button>
          );
        })}
      </div>

      <div className="assistants-controls">
        <div className="field">
          <label>Provider</label>
          <select className="input" value={provider} onChange={(e) => setProvider(e.target.value)}>
            {availableProviders.map(p => (
              <option key={p.id} value={p.id}>
                {p.name}{p.hasKey ? '' : ' (sem key)'}
              </option>
            ))}
          </select>
        </div>

        <button className="btn btn-primary" onClick={run} disabled={isRunning}>
          <Wand2 size={18} />
          {isRunning ? 'Gerando...' : 'Executar'}
        </button>
      </div>

      {error && <div className="alert alert-error">{error}</div>}

      {output && (
        <div className="assistants-output">
          <div className="output-header">
            <h3>Resultado</h3>
            <button className="btn btn-secondary btn-sm" onClick={copyToClipboard}>
              Copiar
            </button>
          </div>
          <pre className="code-block">{output}</pre>
        </div>
      )}

      <style>{`
        .assistants-tools-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
          gap: 12px;
          margin: 16px 0;
        }
        .tool-card {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 8px;
          padding: 16px 12px;
          background: var(--bg-light);
          border: 1px solid var(--border);
          border-radius: 8px;
          cursor: pointer;
          transition: all 0.2s;
          color: var(--text-muted);
        }
        .tool-card:hover {
          border-color: var(--primary);
          color: var(--text);
        }
        .tool-card.active {
          border-color: var(--primary);
          background: rgba(99, 102, 241, 0.1);
          color: var(--primary);
        }
        .tool-card span {
          font-size: 12px;
          text-align: center;
        }
        .output-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 12px;
        }
        .output-header h3 {
          margin: 0;
        }
      `}</style>
    </div>
  );
}
