import React, { useState, useEffect, useRef } from 'react';
import { Play, Square, RotateCcw, Maximize2, Download, Code } from 'lucide-react';

function GamePlayer({ projectFiles, projectName, framework }) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [gameCode, setGameCode] = useState('');
  const [gameHTML, setGameHTML] = useState('');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const iframeRef = useRef(null);
  const containerRef = useRef(null);

  useEffect(() => {
    if (projectFiles && projectFiles.length > 0) {
      buildGameHTML();
    }
  }, [projectFiles]);

  const buildGameHTML = () => {
    // Coletar todos os arquivos JS
    const jsFiles = projectFiles.filter(f => 
      f.path.endsWith('.js') || f.path.endsWith('.ts')
    );

    // Coletar CSS
    const cssFiles = projectFiles.filter(f => f.path.endsWith('.css'));

    // Construir HTML completo
    let html = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${projectName || 'Game'}</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background: #000;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            overflow: hidden;
        }
        canvas {
            display: block;
            background: #222;
        }
        #game-container {
            position: relative;
        }
`;

    // Adicionar CSS customizado
    cssFiles.forEach(cssFile => {
      html += `        ${cssFile.content}\n`;
    });

    html += `    </style>

    <!-- CDNs comuns para frameworks de jogos -->
`;

    // Adicionar CDN baseado no framework
    if (framework) {
      const frameworkCDNs = getFrameworkCDNs(framework);
      frameworkCDNs.forEach(cdn => {
        html += `    <script src="${cdn}"></script>\n`;
      });
    }

    html += `</head>
<body>
    <div id="game-container">
        <canvas id="game-canvas"></canvas>
    </div>

    <script>
        // Wrapper para capturar erros
        window.addEventListener('error', function(e) {
            console.error('Game Error:', e.error);
            const errorDiv = document.createElement('div');
            errorDiv.style.cssText = 'position:fixed;top:10px;left:10px;background:rgba(255,0,0,0.8);color:white;padding:10px;border-radius:5px;max-width:80%;z-index:9999;';
            errorDiv.textContent = 'Erro: ' + e.message;
            document.body.appendChild(errorDiv);
        });

        // Console override para mostrar logs
        const originalLog = console.log;
        const originalError = console.error;
        const logs = [];

        console.log = function(...args) {
            logs.push({type: 'log', args});
            originalLog.apply(console, args);
            window.parent.postMessage({type: 'console', level: 'log', args}, '*');
        };

        console.error = function(...args) {
            logs.push({type: 'error', args});
            originalError.apply(console, args);
            window.parent.postMessage({type: 'console', level: 'error', args}, '*');
        };
    </script>

`;

    // Adicionar código do jogo
    jsFiles.forEach(jsFile => {
      html += `    <script>\n${jsFile.content}\n    </script>\n`;
    });

    html += `
    <script>
        // Notificar que o jogo carregou
        window.parent.postMessage({type: 'game-loaded'}, '*');
    </script>
</body>
</html>`;

    setGameHTML(html);
  };

  const getFrameworkCDNs = (framework) => {
    const cdns = {
      'Phaser': [
        'https://cdn.jsdelivr.net/npm/phaser@3.60.0/dist/phaser.min.js'
      ],
      'PixiJS': [
        'https://cdn.jsdelivr.net/npm/pixi.js@7.3.0/dist/pixi.min.js'
      ],
      'Three.js': [
        'https://cdn.jsdelivr.net/npm/three@0.158.0/build/three.min.js'
      ],
      'Babylon.js': [
        'https://cdn.babylonjs.com/babylon.js'
      ],
      'Kaboom': [
        'https://unpkg.com/kaboom@3000.0.1/dist/kaboom.js'
      ],
      'PlayCanvas': [
        'https://code.playcanvas.com/playcanvas-stable.min.js'
      ]
    };

    for (const [key, urls] of Object.entries(cdns)) {
      if (framework.toLowerCase().includes(key.toLowerCase())) {
        return urls;
      }
    }

    return [];
  };

  const handlePlay = () => {
    if (!gameHTML) {
      alert('Nenhum jogo para executar. Gere código primeiro!');
      return;
    }

    setIsPlaying(true);
    
    // Criar blob URL para o HTML
    const blob = new Blob([gameHTML], { type: 'text/html' });
    const url = URL.createObjectURL(blob);

    // Carregar no iframe
    if (iframeRef.current) {
      iframeRef.current.src = url;
    }
  };

  const handleStop = () => {
    setIsPlaying(false);
    if (iframeRef.current) {
      iframeRef.current.src = 'about:blank';
    }
  };

  const handleRestart = () => {
    handleStop();
    setTimeout(() => handlePlay(), 100);
  };

  const handleFullscreen = () => {
    if (!isFullscreen && containerRef.current) {
      if (containerRef.current.requestFullscreen) {
        containerRef.current.requestFullscreen();
      }
    } else if (document.exitFullscreen) {
      document.exitFullscreen();
    }
    setIsFullscreen(!isFullscreen);
  };

  const handleDownloadHTML = () => {
    if (!gameHTML) return;

    const blob = new Blob([gameHTML], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${projectName || 'game'}.html`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleViewSource = () => {
    if (!gameHTML) return;

    const newWindow = window.open('', '_blank');
    newWindow.document.write('<pre>' + escapeHtml(gameHTML) + '</pre>');
    newWindow.document.close();
  };

  const escapeHtml = (text) => {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  };

  // Receber mensagens do iframe
  useEffect(() => {
    const handleMessage = (event) => {
      if (event.data.type === 'console') {
        console.log(`[Game ${event.data.level}]:`, ...event.data.args);
      } else if (event.data.type === 'game-loaded') {
        console.log('✅ Jogo carregado com sucesso!');
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  return (
    <div className="game-player">
      <div className="player-header">
        <h3>🎮 Game Player</h3>
        <div className="player-controls">
          {!isPlaying ? (
            <button 
              className="btn btn-success btn-sm"
              onClick={handlePlay}
              disabled={!gameHTML}
            >
              <Play size={16} />
              Jogar
            </button>
          ) : (
            <>
              <button 
                className="btn btn-danger btn-sm"
                onClick={handleStop}
              >
                <Square size={16} />
                Parar
              </button>
              <button 
                className="btn btn-secondary btn-sm"
                onClick={handleRestart}
              >
                <RotateCcw size={16} />
                Reiniciar
              </button>
            </>
          )}
          
          <button 
            className="btn btn-secondary btn-sm"
            onClick={handleFullscreen}
            disabled={!isPlaying}
          >
            <Maximize2 size={16} />
            Tela Cheia
          </button>

          <button 
            className="btn btn-secondary btn-sm"
            onClick={handleDownloadHTML}
            disabled={!gameHTML}
          >
            <Download size={16} />
            Download HTML
          </button>

          <button 
            className="btn btn-secondary btn-sm"
            onClick={handleViewSource}
            disabled={!gameHTML}
          >
            <Code size={16} />
            Ver Código
          </button>
        </div>
      </div>

      <div 
        ref={containerRef}
        className={`player-viewport ${isPlaying ? 'playing' : ''}`}
      >
        {!isPlaying ? (
          <div className="player-placeholder">
            <Play size={64} />
            <p>Clique em "Jogar" para executar o jogo</p>
            {!gameHTML && (
              <p className="text-muted">
                Gere código primeiro usando o modo colaborativo
              </p>
            )}
          </div>
        ) : (
          <iframe
            ref={iframeRef}
            className="game-iframe"
            sandbox="allow-scripts allow-same-origin"
            title="Game Player"
          />
        )}
      </div>

      <style jsx>{`
        .game-player {
          display: flex;
          flex-direction: column;
          height: 100%;
          background: var(--bg-darker);
          border: 1px solid var(--border);
          border-radius: 0.5rem;
          overflow: hidden;
        }

        .player-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 1rem;
          background: var(--bg-dark);
          border-bottom: 1px solid var(--border);
        }

        .player-header h3 {
          margin: 0;
          font-size: 1rem;
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }

        .player-controls {
          display: flex;
          gap: 0.5rem;
        }

        .player-viewport {
          flex: 1;
          position: relative;
          background: #000;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .player-placeholder {
          text-align: center;
          color: var(--text-muted);
        }

        .player-placeholder svg {
          opacity: 0.3;
          margin-bottom: 1rem;
        }

        .game-iframe {
          width: 100%;
          height: 100%;
          border: none;
          background: #000;
        }

        .text-muted {
          font-size: 0.875rem;
          opacity: 0.7;
        }
      `}</style>
    </div>
  );
}

export default GamePlayer;
