import axios from 'axios';
import { AI_PROVIDERS, COLLABORATIVE_MODE, GAME_TYPES } from '../config/aiConfig.js';

class CollaborativeAIService {
  constructor() {
    this.providers = AI_PROVIDERS;
    this.apiKeys = {};
    this.providerSettings = {};
    this.loadProviderSettings();
  }

  loadProviderSettings() {
    if (typeof window === 'undefined') return;

    const savedKeys = localStorage.getItem('ai_api_keys');
    if (savedKeys) {
      try { this.apiKeys = JSON.parse(savedKeys) || {}; } catch { this.apiKeys = {}; }
    }

    const savedSettings = localStorage.getItem('ai_provider_settings');
    if (savedSettings) {
      try { this.providerSettings = JSON.parse(savedSettings) || {}; } catch { this.providerSettings = {}; }
    }

    for (const [provider, key] of Object.entries(this.apiKeys || {})) {
      if (!this.providerSettings[provider]) this.providerSettings[provider] = {};
      if (!this.providerSettings[provider].apiKey) this.providerSettings[provider].apiKey = key;
      if (this.providerSettings[provider].enabled === undefined) this.providerSettings[provider].enabled = true;
    }
  }

  saveApiKey(provider, apiKey) {
    this.apiKeys[provider] = apiKey;
    if (typeof window !== 'undefined') {
      localStorage.setItem('ai_api_keys', JSON.stringify(this.apiKeys));
    }
    this.setProviderSetting(provider, { apiKey, enabled: true });
  }

  setProviderSetting(provider, partial) {
    const current = this.providerSettings[provider] || {};
    const next = { ...current, ...partial };
    this.providerSettings[provider] = next;
    if (typeof window !== 'undefined') {
      localStorage.setItem('ai_provider_settings', JSON.stringify(this.providerSettings));
    }
    return next;
  }

  getProviderSetting(provider) {
    return this.providerSettings[provider] || {};
  }

  getEnabledProviders(list) {
    return (list || []).filter(p => {
      const cfg = this.providers[p];
      const st = this.getProviderSetting(p);
      if (st.enabled === false) return false;
      if (cfg?.noKeyRequired) return true;
      return Boolean(st.apiKey || this.apiKeys[p]);
    });
  }

  async collaborativeGenerate(request) {
    const {
      description,
      gameType,
      language,
      framework,
      includeAssets = true,
      includeLibraries = true
    } = request;

    const plan = await this.orchestrate(description, gameType, language);

    const toolContext = {
      web: null,
      github: null,
      assetsHints: null
    };

    if (plan.needsWebResearch && plan.researchQuery) {
      toolContext.web = await this.searchWeb(plan.researchQuery).catch(() => null);
    }

    if (plan.needsGithubResearch && plan.githubQuery) {
      toolContext.github = await this.searchGitHub(plan.githubQuery).catch(() => null);
    }

    const tasks = [];

    if (plan.needsCode) {
      tasks.push(this.generateCode(plan.codeTask, language, framework, toolContext));
    }

    if (includeAssets && plan.needsAssets) {
      tasks.push(this.generateAssets(plan.assetsTask, gameType, toolContext));
    }

    if (includeLibraries && plan.needsLibraries) {
      tasks.push(this.findLibraries(plan.librariesTask, framework, toolContext));
    }

    const results = await Promise.allSettled(tasks);

    return await this.consolidateResults(results, plan, toolContext, { description, gameType, language, framework });
  }

  async orchestrate(description, gameType, language) {
    const orchestratorPrompt = `${COLLABORATIVE_MODE.ORCHESTRATOR.systemPrompt}

Game Description: ${description}
Game Type: ${gameType}
Language: ${language}

Analyze this request and return a JSON plan with:
{
  "needsCode": boolean,
  "needsAssets": boolean,
  "needsLibraries": boolean,
  "needsWebResearch": boolean,
  "needsGithubResearch": boolean,
  "codeTask": "specific code task description",
  "assetsTask": ["list", "of", "assets", "needed"],
  "librariesTask": ["libraries", "to", "find"],
  "researchQuery": "web search query if needed",
  "githubQuery": "github search query if needed",
  "estimatedComplexity": "simple|medium|complex"
}

Return ONLY the JSON, no other text.`;

    try {
      const response = await this.callAI(COLLABORATIVE_MODE.ORCHESTRATOR.provider, orchestratorPrompt, { maxTokens: 1000 });
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      if (jsonMatch) return JSON.parse(jsonMatch[0]);
    } catch (error) {
      console.error('Orchestrator error:', error);
    }

    return {
      needsCode: true,
      needsAssets: true,
      needsLibraries: true,
      needsWebResearch: false,
      needsGithubResearch: false,
      codeTask: description,
      assetsTask: GAME_TYPES[gameType]?.requiredAssets || [],
      librariesTask: GAME_TYPES[gameType]?.requiredLibraries || [],
      estimatedComplexity: 'medium'
    };
  }

  async generateCode(task, language, framework, toolContext) {
    const toolBlock = this.formatToolContext(toolContext);

    const codePrompt = `${COLLABORATIVE_MODE.CODE_SPECIALIST.systemPrompt}

Task: ${task}
Language: ${language}
Framework: ${framework}

${toolBlock}

Generate clean, well-commented, production-ready code.
Include:
- Main game logic
- Proper structure
- Error handling
- Comments explaining key parts

Return ONLY the code, no markdown formatting.`;

    const providers = this.getEnabledProviders(COLLABORATIVE_MODE.CODE_SPECIALIST.providers);
    if (providers.length === 0) {
      return {
        type: 'code',
        content: this.defaultGameTemplate({ description: task, gameType: 'AUTO', language, framework }),
        provider: 'FALLBACK_TEMPLATE',
        alternates: []
      };
    }

    const attempts = providers.slice(0, 3).map(provider =>
      this.callAI(provider, codePrompt, { maxTokens: 4000 })
        .then(code => ({ provider, code, success: true }))
        .catch(error => ({ provider, error: error.message, success: false }))
    );

    const results = await Promise.allSettled(attempts);
    const successful = results
      .filter(r => r.status === 'fulfilled' && r.value.success)
      .map(r => r.value);

    if (successful.length > 0) {
      return {
        type: 'code',
        content: successful[0].code,
        provider: successful[0].provider,
        alternates: successful.slice(1)
      };
    }

    throw new Error('Nenhuma IA conseguiu gerar codigo');
  }

  async generateAssets(assetsList, gameType, toolContext) {
    const assets = [];
    for (const assetName of assetsList) {
      try {
        const assetType = this.determineAssetType(assetName);

        if (assetType === 'image') {
          const imageData = await this.generateImage(assetName, gameType);
          assets.push({ name: assetName, type: 'image', data: imageData, folder: 'assets/images' });
          continue;
        }

        const webAsset = await this.searchGameAssets(`${assetName} ${gameType} game asset`, assetType);
        if (webAsset) {
          assets.push({ name: assetName, type: assetType, data: webAsset, folder: assetType === 'audio' ? 'assets/sounds' : 'assets/models' });
          continue;
        }

        assets.push({
          name: assetName,
          type: assetType,
          data: { placeholder: true, prompt: assetName, note: 'Nao foi possivel gerar/buscar automaticamente.' },
          folder: assetType === 'audio' ? 'assets/sounds' : (assetType === '3d' ? 'assets/models' : 'assets/images')
        });
      } catch (error) {
        console.error(`Erro ao gerar asset ${assetName}:`, error);
        assets.push({
          name: assetName,
          type: 'unknown',
          data: { placeholder: true, prompt: assetName, error: String(error?.message || error) },
          folder: 'assets'
        });
      }
    }

    return { type: 'assets', items: assets };
  }

  determineAssetType(assetName) {
    const name = String(assetName || '').toLowerCase();
    if (name.includes('sprite') || name.includes('texture') || name.includes('icon') || name.includes('tile') || name.includes('background')) return 'image';
    if (name.includes('sound') || name.includes('music') || name.includes('audio') || name.includes('sfx') || name.includes('effect')) return 'audio';
    if (name.includes('model') || name.includes('3d') || name.includes('mesh')) return '3d';
    return 'image';
  }

  async generateImage(prompt, gameType) {
    const enhancedPrompt = `${prompt}, ${gameType} game art style, game asset, clear background, high quality, pixel perfect`;
    const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(enhancedPrompt)}?width=512&height=512`;
    return { url, provider: 'Pollinations', prompt: enhancedPrompt };
  }

  async findLibraries(librariesList, framework, toolContext) {
    const libraries = [];

    for (const libName of librariesList) {
      const cdn = await this.searchCDN(libName).catch(() => null);
      if (cdn) libraries.push({ name: libName, cdn, type: 'library', folder: 'libs' });

      const gh = await this.searchGitHub(`${libName} ${framework}`).catch(() => null);
      if (gh?.results?.length) {
        libraries.push({
          name: `${libName} (GitHub)`,
          github: gh.results.slice(0, 3),
          type: 'library',
          folder: 'libs'
        });
      }
    }

    return { type: 'libraries', items: libraries };
  }

  async searchCDN(libraryName) {
    const response = await axios.get(
      `https://api.cdnjs.com/libraries?search=${encodeURIComponent(libraryName)}&limit=1`
    );

    if (response.data.results && response.data.results.length > 0) {
      const lib = response.data.results[0];
      return { name: lib.name, version: lib.version, url: lib.latest, description: lib.description };
    }
    return null;
  }

  async searchWeb(query) {
    const response = await axios.post('/api/web/search', {
      query,
      provider: 'DUCKDUCKGO'
    });
    return response.data;
  }

  async searchGitHub(query) {
    const st = this.getProviderSetting('GITHUB') || {};
    const response = await axios.post('/api/github/search', {
      query,
      token: st.apiKey || null
    });
    return response.data;
  }

  async searchGameAssets(query, type) {
    const response = await axios.post('/api/assets/search', { query, type });
    return response.data;
  }

  formatToolContext(toolContext) {
    const blocks = [];
    if (toolContext?.web?.results?.length) {
      blocks.push(`WEB SEARCH RESULTS (use these as references; do not fabricate sources):
${toolContext.web.results.slice(0, 5).map((r, i) => `${i + 1}. ${r.title} - ${r.url}\n   ${r.snippet || ''}`).join('\n')}`);
    }
    if (toolContext?.github?.results?.length) {
      blocks.push(`GITHUB RESULTS (repos that may be useful):
${toolContext.github.results.slice(0, 5).map((r, i) => `${i + 1}. ${r.full_name} - ${r.html_url}\n   Stars: ${r.stars} | ${r.description || ''}`).join('\n')}`);
    }
    if (blocks.length === 0) return '';
    return `\n\n=== TOOL CONTEXT ===\n${blocks.join('\n\n')}\n=== END TOOL CONTEXT ===\n\n`;
  }

  defaultGameTemplate({ description, gameType, language, framework }) {
    const title = (description || 'Game').slice(0, 60);
    return `// Auto-generated game code
// Title: ${title}
// Type: ${gameType}
// Framework: ${framework || 'Vanilla Canvas'}

(function () {
  const canvas = document.getElementById('game-canvas');
  const ctx = canvas.getContext('2d');

  const DPR = Math.max(1, window.devicePixelRatio || 1);
  function resize() {
    const w = Math.min(window.innerWidth, 960);
    const h = Math.min(window.innerHeight, 540);
    canvas.style.width = w + 'px';
    canvas.style.height = h + 'px';
    canvas.width = Math.floor(w * DPR);
    canvas.height = Math.floor(h * DPR);
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
  }
  window.addEventListener('resize', resize);
  resize();

  const state = {
    t: 0,
    player: { x: 120, y: 120, w: 24, h: 24, vx: 0, vy: 0, speed: 200 },
    keys: {},
    score: 0,
    coins: [],
    enemies: []
  };

  // Generate coins
  for (let i = 0; i < 10; i++) {
    state.coins.push({
      x: Math.random() * 800 + 50,
      y: Math.random() * 400 + 50,
      collected: false
    });
  }

  // Generate enemies
  for (let i = 0; i < 3; i++) {
    state.enemies.push({
      x: Math.random() * 600 + 100,
      y: Math.random() * 300 + 100,
      vx: (Math.random() - 0.5) * 100,
      vy: (Math.random() - 0.5) * 100
    });
  }

  window.addEventListener('keydown', (e) => { state.keys[e.key.toLowerCase()] = true; });
  window.addEventListener('keyup', (e) => { state.keys[e.key.toLowerCase()] = false; });

  function update(dt) {
    const k = state.keys;
    const ax = (k['arrowright'] || k['d'] ? 1 : 0) - (k['arrowleft'] || k['a'] ? 1 : 0);
    const ay = (k['arrowdown'] || k['s'] ? 1 : 0) - (k['arrowup'] || k['w'] ? 1 : 0);
    const len = Math.hypot(ax, ay) || 1;
    state.player.vx = (ax / len) * state.player.speed;
    state.player.vy = (ay / len) * state.player.speed;
    state.player.x += state.player.vx * dt;
    state.player.y += state.player.vy * dt;

    const w = canvas.clientWidth;
    const h = canvas.clientHeight;
    state.player.x = Math.max(0, Math.min(w - state.player.w, state.player.x));
    state.player.y = Math.max(0, Math.min(h - state.player.h, state.player.y));

    // Coin collection
    state.coins.forEach(coin => {
      if (!coin.collected && 
          Math.abs(state.player.x - coin.x) < 20 && 
          Math.abs(state.player.y - coin.y) < 20) {
        coin.collected = true;
        state.score += 10;
      }
    });

    // Enemy movement
    state.enemies.forEach(enemy => {
      enemy.x += enemy.vx * dt;
      enemy.y += enemy.vy * dt;
      if (enemy.x < 0 || enemy.x > w - 20) enemy.vx *= -1;
      if (enemy.y < 0 || enemy.y > h - 20) enemy.vy *= -1;
    });
  }

  function draw() {
    const w = canvas.clientWidth;
    const h = canvas.clientHeight;

    ctx.fillStyle = '#1a1a2e';
    ctx.fillRect(0, 0, w, h);

    // Grid
    ctx.globalAlpha = 0.1;
    ctx.strokeStyle = '#4a4a6a';
    for (let x = 0; x < w; x += 32) { ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,h); ctx.stroke(); }
    for (let y = 0; y < h; y += 32) { ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(w,y); ctx.stroke(); }
    ctx.globalAlpha = 1;

    // Coins
    ctx.fillStyle = '#ffd700';
    state.coins.forEach(coin => {
      if (!coin.collected) {
        ctx.beginPath();
        ctx.arc(coin.x, coin.y, 8, 0, Math.PI * 2);
        ctx.fill();
      }
    });

    // Enemies
    ctx.fillStyle = '#ff4444';
    state.enemies.forEach(enemy => {
      ctx.fillRect(enemy.x, enemy.y, 20, 20);
    });

    // Player
    ctx.fillStyle = '#6ee7ff';
    ctx.fillRect(state.player.x, state.player.y, state.player.w, state.player.h);

    // UI
    ctx.fillStyle = 'rgba(0,0,0,0.6)';
    ctx.fillRect(10, 10, 200, 50);
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 16px sans-serif';
    ctx.fillText('${title}', 20, 32);
    ctx.font = '14px sans-serif';
    ctx.fillText('Score: ' + state.score, 20, 50);
  }

  let last = performance.now();
  function loop(now) {
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    state.t += dt;
    update(dt);
    draw();
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);
})();
`;
  }

  async consolidateResults(results, plan, toolContext, req) {
    const consolidated = {
      code: null,
      assets: [],
      libraries: [],
      webResearch: toolContext?.web || null,
      githubResearch: toolContext?.github || null,
      metadata: {
        plan,
        generatedAt: new Date().toISOString(),
        providersUsed: []
      }
    };

    results.forEach((result) => {
      if (result.status !== 'fulfilled' || !result.value) return;
      const data = result.value;
      if (data.type === 'code') {
        consolidated.code = data;
        consolidated.metadata.providersUsed.push(data.provider);
      } else if (data.type === 'assets') {
        consolidated.assets = data.items;
      } else if (data.type === 'libraries') {
        consolidated.libraries = data.items;
      }
    });

    if (!consolidated.code) {
      consolidated.code = {
        type: 'code',
        content: this.defaultGameTemplate({ description: req?.description || plan?.codeTask || 'Game', gameType: req?.gameType || 'AUTO', language: req?.language || 'JavaScript', framework: req?.framework || 'Vanilla Canvas' }),
        provider: 'FALLBACK_TEMPLATE',
        alternates: []
      };
    }

    return consolidated;
  }

  async callAI(providerName, prompt, options = {}) {
    const { maxTokens = 2000, temperature = 0.7, modelOverride } = options;
    const provider = this.providers[providerName];
    if (!provider) throw new Error(`Provider ${providerName} not found`);

    if (providerName === 'HUGGINGFACE') {
      return await this.callHuggingFace(prompt, maxTokens);
    }

    if (providerName === 'GOOGLE_GEMINI') {
      return await this.callGemini(prompt, maxTokens);
    }

    if (providerName === 'ANTHROPIC') {
      return await this.callAnthropic(prompt, maxTokens);
    }

    if (providerName === 'COHERE') {
      return await this.callCohere(prompt, maxTokens);
    }

    if (provider?.openAICompatible || ['GROQ','DEEPINFRA','TOGETHER','OPENAI','CUSTOM_OPENAI','OPENROUTER','FIREWORKS','MISTRAL_API','PERPLEXITY','CEREBRAS','OLLAMA_LOCAL','LMSTUDIO_LOCAL'].includes(providerName)) {
      const st = this.getProviderSetting(providerName);
      const apiKey = st.apiKey || this.apiKeys[providerName];
      const baseUrl = st.baseUrl || provider.endpoint;
      const model = modelOverride || st.model || provider.models?.coding || provider.models?.chat || provider.models?.fast || provider.models?.textGeneration;

      const noAuth = Boolean(provider?.noKeyRequired || st.noAuth || (!apiKey && /localhost|127\.0\.0\.1/.test(String(baseUrl || ''))));
      if (!noAuth && !apiKey) throw new Error(`${providerName} API key not set`);

      const response = await axios.post('/api/chat', {
        provider: providerName,
        apiKey: apiKey || null,
        baseUrl,
        model,
        noAuth,
        messages: [{ role: 'user', content: prompt }],
        max_tokens: maxTokens,
        temperature
      });

      return response.data?.content || '';
    }

    throw new Error(`Provider ${providerName} not implemented`);
  }

  async callHuggingFace(prompt, maxTokens) {
    const st = this.getProviderSetting('HUGGINGFACE');
    const apiKey = st.apiKey || this.apiKeys.HUGGINGFACE;
    if (!apiKey) throw new Error('HuggingFace API key not set');

    const model = st.model || this.providers.HUGGINGFACE?.models?.textGeneration || 'mistralai/Mistral-7B-Instruct-v0.2';

    const response = await axios.post('/api/hf', {
      apiKey,
      model,
      inputs: prompt,
      parameters: {
        max_new_tokens: maxTokens,
        temperature: 0.7,
        return_full_text: false
      }
    });

    const data = response.data?.data;
    if (Array.isArray(data)) return data[0]?.generated_text || '';
    return data?.generated_text || '';
  }

  async callGemini(prompt, maxTokens) {
    const st = this.getProviderSetting('GOOGLE_GEMINI');
    const apiKey = st.apiKey || this.apiKeys.GOOGLE_GEMINI;
    if (!apiKey) throw new Error('Google Gemini API key not set');

    const model = st.model || 'gemini-2.0-flash-exp';

    const response = await axios.post('/api/gemini', {
      apiKey,
      model,
      prompt,
      maxTokens
    });

    return response.data?.content || '';
  }

  async callAnthropic(prompt, maxTokens) {
    const st = this.getProviderSetting('ANTHROPIC');
    const apiKey = st.apiKey || this.apiKeys.ANTHROPIC;
    if (!apiKey) throw new Error('Anthropic API key not set');

    const model = st.model || 'claude-3-5-sonnet-20241022';

    const response = await axios.post('/api/anthropic', {
      apiKey,
      model,
      prompt,
      maxTokens
    });

    return response.data?.content || '';
  }

  async callCohere(prompt, maxTokens) {
    const st = this.getProviderSetting('COHERE');
    const apiKey = st.apiKey || this.apiKeys.COHERE;
    if (!apiKey) throw new Error('Cohere API key not set');

    const model = st.model || 'command-r-plus';

    const response = await axios.post('/api/cohere', {
      apiKey,
      model,
      prompt,
      maxTokens
    });

    return response.data?.content || '';
  }
}

export default new CollaborativeAIService();
