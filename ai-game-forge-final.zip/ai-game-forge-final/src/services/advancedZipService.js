import JSZip from 'jszip';
import { PROJECT_STRUCTURE, ASSET_TYPES } from '../config/aiConfig.js';

class AdvancedZipService {
  constructor() {
    this.zip = null;
  }

  /**
   * Cria projeto organizado automaticamente
   */
  async createOrganizedProject(projectData) {
    const {
      projectName,
      language,
      framework,
      gameType,
      collaborativeResult,
      platform = 'WEB_GAME'
    } = projectData;

    const zip = new JSZip();
    
    // Obter estrutura baseada na plataforma
    const structure = PROJECT_STRUCTURE[platform] || PROJECT_STRUCTURE.WEB_GAME;

    // Criar todas as pastas
    structure.folders.forEach(folder => {
      zip.folder(folder);
    });

    // Organizar código
    if (collaborativeResult?.code) {
      const codeContent = collaborativeResult.code.content;
      const mainFile = this.getMainFileName(language, framework);
      zip.file(`src/${mainFile}`, codeContent);

      // Se tiver alternativas, salvar em pasta separada
      if (collaborativeResult.code.alternates) {
        collaborativeResult.code.alternates.forEach((alt, index) => {
          zip.file(`src/alternates/${alt.provider}_${mainFile}`, alt.code);
        });
      }
    }

    // Organizar assets
    if (collaborativeResult?.assets) {
      for (const asset of collaborativeResult.assets) {
        const folder = asset.folder || this.determineAssetFolder(asset.type);
        
        if (asset.data?.base64) {
  // Salvar imagem/áudio base64
  const isDataUrl = /^data:/i.test(asset.data.base64);
  const raw = isDataUrl ? asset.data.base64.split(',')[1] : asset.data.base64;
  const ext = asset.type === 'audio' ? 'mp3' : 'png';
  zip.file(`${folder}/${asset.name}.${ext}`, raw, { base64: true });
} else if (asset.data?.url) {
  // Tentar baixar a URL via proxy (para entregar um ZIP completo)
  try {
    const resp = await fetch('/api/fetch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: asset.data.url })
    });
    const data = await resp.json();
    if (resp.ok && data?.base64) {
      const ext = /^audio\//i.test(data.contentType || '') ? 'mp3' : 'png';
      zip.file(`${folder}/${asset.name}.${ext}`, data.base64, { base64: true });
    } else {
      zip.file(`${folder}/${asset.name}_ref.txt`, asset.data.url);
    }
  } catch (e) {
    zip.file(`${folder}/${asset.name}_ref.txt`, asset.data.url);
  }
} else if (asset.data?.base64) {
          // Salvar imagem base64
          const imgData = asset.data.base64.replace(/^data:image\/\w+;base64,/, '');
          zip.file(`${folder}/${asset.name}.png`, imgData, { base64: true });
        } else if (asset.data?.placeholder) {
          // Criar placeholder
          zip.file(`${folder}/${asset.name}.txt`, 
            `Placeholder for: ${asset.data.prompt}\n${asset.data.note}`);
        }
      }
    }

    // Organizar bibliotecas
    if (collaborativeResult?.libraries) {
      const libsReadme = this.generateLibrariesReadme(collaborativeResult.libraries);
      zip.file('libs/README.md', libsReadme);

      // Criar arquivo de imports
      const imports = this.generateImportsFile(collaborativeResult.libraries, framework);
      zip.file('libs/imports.txt', imports);
    }

    // Criar HTML principal para jogos web
    if (platform === 'WEB_GAME') {
      const html = this.generateIndexHTML(projectName, collaborativeResult);
      zip.file('index.html', html);
    }

    // README principal
    const readme = this.generateMainReadme(projectData, collaborativeResult);
    zip.file('README.md', readme);

    // package.json para JavaScript
    if (language === 'JavaScript' || language === 'TypeScript') {
      const packageJson = this.generatePackageJson(projectName, framework, collaborativeResult);
      zip.file('package.json', JSON.stringify(packageJson, null, 2));
    }

    // .gitignore
    zip.file('.gitignore', this.generateGitignore(platform));

    // Metadata do projeto
    const metadata = {
      generatedAt: new Date().toISOString(),
      aiProviders: collaborativeResult?.metadata?.providersUsed || [],
      gameType: gameType,
      language: language,
      framework: framework,
      version: '1.0.0'
    };
    zip.file('project-metadata.json', JSON.stringify(metadata, null, 2));

    // Gerar ZIP
    const blob = await zip.generateAsync({ 
      type: 'blob',
      compression: 'DEFLATE',
      compressionOptions: { level: 9 }
    });

    return blob;
  }

  getMainFileName(language, framework) {
    const fileNames = {
      'JavaScript': 'main.js',
      'TypeScript': 'main.ts',
      'Python': 'main.py',
      'C#': 'GameManager.cs',
      'GDScript': 'main.gd',
      'C++': 'main.cpp'
    };
    return fileNames[language] || 'main.js';
  }

  determineAssetFolder(type) {
    const folders = {
      'image': 'assets/images',
      'audio': 'assets/sounds',
      '3d': 'assets/models',
      'library': 'libs'
    };
    return folders[type] || 'assets';
  }

  generateLibrariesReadme(libraries) {
    let readme = '# Bibliotecas Necessárias\n\n';
    readme += 'Este projeto utiliza as seguintes bibliotecas:\n\n';

    libraries.forEach(lib => {
      readme += `## ${lib.name}\n`;
      if (lib.cdn?.url) {
        readme += `- **CDN:** ${lib.cdn.url}\n`;
        readme += `- **Versão:** ${lib.cdn.version}\n`;
        if (lib.cdn.description) {
          readme += `- **Descrição:** ${lib.cdn.description}\n`;
        }
      }
      readme += '\n';
    });

    return readme;
  }

  generateImportsFile(libraries, framework) {
    let imports = '// Adicione estas linhas ao seu HTML ou projeto\n\n';
    
    libraries.forEach(lib => {
      if (lib.cdn?.url) {
        imports += `<script src="${lib.cdn.url}"></script>\n`;
      }
    });

    return imports;
  }

  generateIndexHTML(projectName, collaborativeResult) {
    const libs = collaborativeResult?.libraries || [];
    const libScripts = libs.map(lib => 
      lib.cdn?.url ? `    <script src="${lib.cdn.url}"></script>` : ''
    ).filter(Boolean).join('\n');

    return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${projectName}</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background: #000;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            font-family: Arial, sans-serif;
        }
        #game-container {
            position: relative;
        }
        canvas {
            display: block;
            background: #222;
        }
    </style>
</head>
<body>
    <div id="game-container">
        <canvas id="game-canvas"></canvas>
    </div>

    <!-- Bibliotecas -->
${libScripts}

    <!-- Código do jogo -->
    <script src="src/main.js"></script>
</body>
</html>`;
  }

  generateMainReadme(projectData, collaborativeResult) {
    const { projectName, language, framework, gameType } = projectData;

    let readme = `# ${projectName}\n\n`;
    readme += `**Tipo:** ${gameType}\n`;
    readme += `**Linguagem:** ${language}\n`;
    readme += `**Framework:** ${framework}\n\n`;

    readme += `## 🎮 Sobre o Projeto\n\n`;
    readme += `Este jogo foi gerado usando AI Game Forge Pro com múltiplas IAs colaborativas.\n\n`;

    if (collaborativeResult?.metadata?.providersUsed) {
      readme += `### IAs Utilizadas\n`;
      collaborativeResult.metadata.providersUsed.forEach(provider => {
        readme += `- ${provider}\n`;
      });
      readme += '\n';
    }

    readme += `## 🚀 Como Executar\n\n`;
    
    if (language === 'JavaScript' || language === 'TypeScript') {
      readme += `### Opção 1: Servidor Local\n`;
      readme += '```bash\n';
      readme += 'npm install\n';
      readme += 'npm start\n';
      readme += '```\n\n';
      
      readme += `### Opção 2: Abrir Diretamente\n`;
      readme += `Abra o arquivo \`index.html\` no seu navegador.\n\n`;
    } else if (language === 'Python') {
      readme += '```bash\n';
      readme += 'pip install -r requirements.txt\n';
      readme += 'python main.py\n';
      readme += '```\n\n';
    }

    readme += `## 📁 Estrutura do Projeto\n\n`;
    readme += '```\n';
    readme += `${projectName}/\n`;
    readme += '├── src/          # Código fonte\n';
    readme += '├── assets/       # Recursos do jogo\n';
    readme += '│   ├── images/   # Sprites e texturas\n';
    readme += '│   ├── sounds/   # Áudio e música\n';
    readme += '│   └── models/   # Modelos 3D\n';
    readme += '├── libs/         # Bibliotecas\n';
    readme += '└── README.md     # Este arquivo\n';
    readme += '```\n\n';

    if (collaborativeResult?.assets && collaborativeResult.assets.length > 0) {
      readme += `## 🎨 Assets Gerados\n\n`;
      collaborativeResult.assets.forEach(asset => {
        readme += `- **${asset.name}** (${asset.type})\n`;
      });
      readme += '\n';
    }

    readme += `## 📝 Notas\n\n`;
    readme += `- Projeto gerado em: ${new Date().toLocaleDateString('pt-BR')}\n`;
    readme += `- Versão: 1.0.0\n`;
    readme += `- Gerado com: AI Game Forge Pro\n\n`;

    readme += `## 🤝 Contribuindo\n\n`;
    readme += `Sinta-se livre para modificar e melhorar este projeto!\n`;

    return readme;
  }

  generatePackageJson(projectName, framework, collaborativeResult) {
    const dependencies = {};
    
    // Adicionar dependências baseadas no framework
    if (framework.toLowerCase().includes('phaser')) {
      dependencies['phaser'] = '^3.60.0';
    } else if (framework.toLowerCase().includes('pixi')) {
      dependencies['pixi.js'] = '^7.0.0';
    } else if (framework.toLowerCase().includes('three')) {
      dependencies['three'] = '^0.158.0';
    } else if (framework.toLowerCase().includes('babylon')) {
      dependencies['@babylonjs/core'] = '^6.0.0';
    }

    return {
      name: projectName.toLowerCase().replace(/\s+/g, '-'),
      version: '1.0.0',
      description: `${framework} game generated with AI Game Forge Pro`,
      main: 'src/main.js',
      scripts: {
        start: 'npx http-server -p 8080',
        dev: 'npx vite',
        build: 'npx vite build'
      },
      dependencies: dependencies,
      devDependencies: {
        'http-server': '^14.1.1',
        'vite': '^5.0.0'
      }
    };
  }

  generateGitignore(platform) {
    return `# Dependencies
node_modules/
vendor/

# Build
dist/
build/
*.exe

# IDE
.vscode/
.idea/
*.swp

# OS
.DS_Store
Thumbs.db

# Logs
*.log

# Environment
.env
.env.local
`;
  }

  /**
   * Analisa ZIP e separa por categorias
   */
  async analyzeAndCategorize(zipBlob) {
    const zip = new JSZip();
    const loadedZip = await zip.loadAsync(zipBlob);

    const categories = {
      code: [],
      images: [],
      audio: [],
      models: [],
      libraries: [],
      docs: [],
      other: []
    };

    for (const [path, zipEntry] of Object.entries(loadedZip.files)) {
      if (zipEntry.dir) continue;

      const ext = path.split('.').pop().toLowerCase();
      const category = this.categorizeFile(ext);
      
      const content = await zipEntry.async('string');
      categories[category].push({
        path: path,
        content: content,
        size: content.length,
        extension: ext
      });
    }

    return categories;
  }

  categorizeFile(extension) {
    const categories = {
      code: ['js', 'ts', 'py', 'cs', 'cpp', 'h', 'gd', 'java', 'rs', 'go'],
      images: ['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'bmp'],
      audio: ['mp3', 'wav', 'ogg', 'm4a', 'flac'],
      models: ['obj', 'fbx', 'gltf', 'glb', 'blend', 'dae'],
      libraries: ['min.js', 'bundle.js'],
      docs: ['md', 'txt', 'pdf', 'doc', 'docx']
    };

    for (const [category, exts] of Object.entries(categories)) {
      if (exts.includes(extension)) {
        return category;
      }
    }

    return 'other';
  }

  /**
   * Reorganiza projeto automaticamente
   */
  async reorganizeProject(zipBlob, targetStructure = 'WEB_GAME') {
    const categorized = await this.analyzeAndCategorize(zipBlob);
    const structure = PROJECT_STRUCTURE[targetStructure];

    const zip = new JSZip();

    // Criar estrutura de pastas
    structure.folders.forEach(folder => {
      zip.folder(folder);
    });

    // Redistribuir arquivos
    categorized.code.forEach(file => {
      zip.file(`src/${file.path.split('/').pop()}`, file.content);
    });

    categorized.images.forEach(file => {
      zip.file(`assets/images/${file.path.split('/').pop()}`, file.content);
    });

    categorized.audio.forEach(file => {
      zip.file(`assets/sounds/${file.path.split('/').pop()}`, file.content);
    });

    categorized.models.forEach(file => {
      zip.file(`assets/models/${file.path.split('/').pop()}`, file.content);
    });

    categorized.libraries.forEach(file => {
      zip.file(`libs/${file.path.split('/').pop()}`, file.content);
    });

    const blob = await zip.generateAsync({ 
      type: 'blob',
      compression: 'DEFLATE',
      compressionOptions: { level: 9 }
    });

    return blob;
  }

  downloadZip(blob, filename) {
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename || 'project.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
}

export default new AdvancedZipService();
