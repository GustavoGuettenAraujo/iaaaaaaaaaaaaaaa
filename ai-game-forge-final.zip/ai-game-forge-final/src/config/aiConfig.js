export const AI_PROVIDERS = {
  HUGGINGFACE: {
    name: 'HuggingFace',
    type: 'code',
    endpoint: 'https://api-inference.huggingface.co/models',
    models: {
      codeGeneration: 'bigcode/starcoder2-15b',
      textGeneration: 'mistralai/Mistral-7B-Instruct-v0.2',
      chat: 'meta-llama/Llama-2-7b-chat-hf',
    },
    free: true,
    rateLimit: '1000 requests/day'
  },
  
  GROQ: {
    name: 'Groq',
    type: 'code',
    endpoint: 'https://api.groq.com/openai/v1',
    models: {
      fast: 'llama-3.3-70b-versatile',
      coding: 'llama-3.3-70b-versatile',
    },
    free: true,
    rateLimit: '14400 requests/day',
    openAICompatible: true
  },

  TOGETHER: {
    name: 'Together AI',
    type: 'code',
    endpoint: 'https://api.together.xyz/v1',
    models: {
      codeGeneration: 'codellama/CodeLlama-34b-Instruct-hf',
      textGeneration: 'mistralai/Mixtral-8x7B-Instruct-v0.1',
    },
    free: true,
    rateLimit: '60 requests/minute',
    openAICompatible: true
  },

  DEEPINFRA: {
    name: 'DeepInfra',
    type: 'code',
    endpoint: 'https://api.deepinfra.com/v1/openai',
    models: {
      codeGeneration: 'codellama/CodeLlama-34b-Instruct-hf',
      chat: 'meta-llama/Meta-Llama-3.1-70B-Instruct',
    },
    free: true,
    rateLimit: 'Unlimited free tier',
    openAICompatible: true
  },

  OPENAI: {
    name: 'OpenAI',
    type: 'code',
    endpoint: 'https://api.openai.com/v1',
    models: {
      chat: 'gpt-4o-mini'
    },
    free: false,
    rateLimit: 'Based on your plan',
    openAICompatible: true
  },

  ANTHROPIC: {
    name: 'Anthropic Claude',
    type: 'code',
    endpoint: 'https://api.anthropic.com/v1',
    models: {
      chat: 'claude-3-5-sonnet-20241022'
    },
    free: false,
    rateLimit: 'Based on your plan'
  },

  GOOGLE_GEMINI: {
    name: 'Google Gemini',
    type: 'code',
    endpoint: 'https://generativelanguage.googleapis.com/v1beta',
    models: {
      chat: 'gemini-2.0-flash-exp'
    },
    free: true,
    rateLimit: '15 requests/minute'
  },

  COHERE: {
    name: 'Cohere',
    type: 'code',
    endpoint: 'https://api.cohere.ai/v1',
    models: {
      chat: 'command-r-plus'
    },
    free: true,
    rateLimit: '20 requests/minute'
  },

  PERPLEXITY: {
    name: 'Perplexity AI',
    type: 'code',
    endpoint: 'https://api.perplexity.ai',
    models: {
      chat: 'llama-3.1-sonar-large-128k-online'
    },
    free: false,
    rateLimit: 'Based on your plan',
    openAICompatible: true
  },

  CEREBRAS: {
    name: 'Cerebras',
    type: 'code',
    endpoint: 'https://api.cerebras.ai/v1',
    models: {
      chat: 'llama3.1-70b'
    },
    free: true,
    rateLimit: '30 requests/minute',
    openAICompatible: true
  },

  CUSTOM_OPENAI: {
    name: 'Custom OpenAI-Compatible',
    type: 'code',
    endpoint: 'https://example.com/v1',
    models: {
      chat: 'your-model-id'
    },
    free: false,
    rateLimit: 'Depends on provider',
    openAICompatible: true
  },

  OPENROUTER: {
    name: 'OpenRouter',
    type: 'code',
    endpoint: 'https://openrouter.ai/api/v1',
    models: {
      chat: 'openai/gpt-4o-mini'
    },
    openAICompatible: true,
    free: false,
    rateLimit: 'Depends on plan'
  },

  FIREWORKS: {
    name: 'Fireworks AI',
    type: 'code',
    endpoint: 'https://api.fireworks.ai/inference/v1',
    models: {
      chat: 'accounts/fireworks/models/llama-v3p1-70b-instruct'
    },
    openAICompatible: true,
    free: false,
    rateLimit: 'Depends on plan'
  },

  MISTRAL_API: {
    name: 'Mistral API',
    type: 'code',
    endpoint: 'https://api.mistral.ai/v1',
    models: {
      chat: 'mistral-large-latest'
    },
    openAICompatible: true,
    free: false,
    rateLimit: 'Depends on plan'
  },

  OLLAMA_LOCAL: {
    name: 'Ollama (Local)',
    type: 'code',
    endpoint: 'http://localhost:11434/v1',
    models: {
      chat: 'llama3.1'
    },
    openAICompatible: true,
    noKeyRequired: true,
    free: true,
    rateLimit: 'Local'
  },

  LMSTUDIO_LOCAL: {
    name: 'LM Studio (Local)',
    type: 'code',
    endpoint: 'http://localhost:1234/v1',
    models: {
      chat: 'local-model'
    },
    openAICompatible: true,
    noKeyRequired: true,
    free: true,
    rateLimit: 'Local'
  },

  GITHUB: {
    name: 'GitHub Token (optional)',
    type: 'search',
    endpoint: 'https://api.github.com',
    models: { search: 'repos' },
    free: true,
    rateLimit: 'Higher with token'
  },

  OPENVERSE: {
    name: 'Openverse (CC Assets)',
    type: 'assets',
    endpoint: 'https://api.openverse.engineering/v1',
    models: { images: 'images', audio: 'audio' },
    free: true,
    rateLimit: 'Public',
    noKeyRequired: true
  },

  POLYHAVEN: {
    name: 'Poly Haven (Textures/HDRI)',
    type: 'assets',
    endpoint: 'https://api.polyhaven.com',
    models: { assets: 'assets' },
    free: true,
    rateLimit: 'Public',
    noKeyRequired: true
  },

  STABILITY_FREE: {
    name: 'Stability AI (Free)',
    type: 'image',
    endpoint: 'https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-xl-base-1.0',
    models: {
      sdxl: 'stable-diffusion-xl-base-1.0',
      sd21: 'stable-diffusion-2-1',
    },
    free: true,
    rateLimit: 'Via HuggingFace'
  },

  REPLICATE_IMG: {
    name: 'Replicate Images',
    type: 'image',
    endpoint: 'https://api.replicate.com/v1',
    models: {
      sdxl: 'stability-ai/sdxl',
      playground: 'playgroundai/playground-v2.5-1024px-aesthetic',
      pixelArt: 'nateraw/stable-diffusion-pixel-art',
    },
    free: true,
    rateLimit: 'Limited free tier'
  },

  POLLINATIONS: {
    name: 'Pollinations AI',
    type: 'image',
    endpoint: 'https://image.pollinations.ai/prompt',
    models: {
      default: 'pollinations',
    },
    free: true,
    rateLimit: 'Unlimited',
    noKeyRequired: true
  },

  CRAIYON: {
    name: 'Craiyon (DALL-E Mini)',
    type: 'image',
    endpoint: 'https://api.craiyon.com/v3',
    models: {
      default: 'craiyon-v3',
    },
    free: true,
    rateLimit: 'Limited',
    noKeyRequired: true
  },

  LEONARDO: {
    name: 'Leonardo.AI',
    type: 'image',
    endpoint: 'https://cloud.leonardo.ai/api/rest/v1',
    models: {
      default: 'leonardo-diffusion-xl'
    },
    free: true,
    rateLimit: '150 credits/day free'
  },

  IDEOGRAM: {
    name: 'Ideogram',
    type: 'image',
    endpoint: 'https://api.ideogram.ai/generate',
    models: {
      default: 'ideogram-v2'
    },
    free: true,
    rateLimit: '25 images/day free'
  },

  MESHY: {
    name: 'Meshy AI',
    type: '3d',
    endpoint: 'https://api.meshy.ai/v1',
    models: {
      textTo3D: 'text-to-3d',
      imageToModel: 'image-to-3d',
    },
    free: true,
    rateLimit: '200 credits/month free'
  },

  TRIPO3D: {
    name: 'Tripo3D',
    type: '3d',
    endpoint: 'https://api.tripo3d.ai/v1',
    models: {
      textTo3D: 'text-to-model',
      draft: 'draft-mode',
    },
    free: true,
    rateLimit: 'Free tier available'
  },

  SUNO_FREE: {
    name: 'Suno AI',
    type: 'audio',
    endpoint: 'https://api.suno.ai/v1',
    models: {
      music: 'suno-v3.5',
    },
    free: false,
    rateLimit: '50 songs/month free'
  },

  ELEVENLABS_FREE: {
    name: 'ElevenLabs (Free tier)',
    type: 'audio',
    endpoint: 'https://api.elevenlabs.io/v1',
    models: {
      tts: 'eleven_multilingual_v2',
    },
    free: true,
    rateLimit: '10k characters/month'
  },

  MUBERT: {
    name: 'Mubert (Music)',
    type: 'audio',
    endpoint: 'https://api.mubert.com/v2',
    models: {
      music: 'mubert-ai'
    },
    free: true,
    rateLimit: '25 tracks/month free'
  },

  FAKEYOU: {
    name: 'FakeYou TTS',
    type: 'audio',
    endpoint: 'https://api.fakeyou.com',
    models: {
      tts: 'tts',
    },
    free: true,
    rateLimit: 'Limited',
    noKeyRequired: true
  },

  UBERDUCK: {
    name: 'Uberduck',
    type: 'audio',
    endpoint: 'https://api.uberduck.ai',
    models: {
      tts: 'tts-voices'
    },
    free: true,
    rateLimit: 'Limited free tier'
  },

  SERPER: {
    name: 'Serper (Google Search)',
    type: 'search',
    endpoint: 'https://google.serper.dev/search',
    models: {
      search: 'search',
      images: 'images',
      news: 'news',
    },
    free: true,
    rateLimit: '2500 requests free'
  },

  BRAVE_SEARCH: {
    name: 'Brave Search',
    type: 'search',
    endpoint: 'https://api.search.brave.com/res/v1',
    models: {
      web: 'web',
    },
    free: true,
    rateLimit: '2000 requests/month'
  },

  DUCKDUCKGO: {
    name: 'DuckDuckGo',
    type: 'search',
    endpoint: 'https://api.duckduckgo.com',
    models: {
      instant: 'instant',
    },
    free: true,
    rateLimit: 'Unlimited',
    noKeyRequired: true
  },

  TAVILY: {
    name: 'Tavily Search',
    type: 'search',
    endpoint: 'https://api.tavily.com/search',
    models: {
      search: 'search'
    },
    free: true,
    rateLimit: '1000 requests/month free'
  },

  JSDELIVR: {
    name: 'jsDelivr CDN',
    type: 'library',
    endpoint: 'https://data.jsdelivr.com/v1',
    models: {
      search: 'packages',
    },
    free: true,
    rateLimit: 'Unlimited',
    noKeyRequired: true
  },

  CDNJS: {
    name: 'cdnjs',
    type: 'library',
    endpoint: 'https://api.cdnjs.com',
    models: {
      search: 'libraries',
    },
    free: true,
    rateLimit: 'Unlimited',
    noKeyRequired: true
  },

  OPENGAMEART: {
    name: 'OpenGameArt',
    type: 'assets',
    endpoint: 'https://opengameart.org/api',
    models: {
      search: 'art',
    },
    free: true,
    rateLimit: 'Unlimited',
    noKeyRequired: true
  },

  FREESOUND: {
    name: 'Freesound',
    type: 'assets',
    endpoint: 'https://freesound.org/apiv2',
    models: {
      search: 'sounds',
    },
    free: true,
    rateLimit: 'Requires API key (free)'
  },

  KENNEY: {
    name: 'Kenney Assets',
    type: 'assets',
    endpoint: 'https://kenney.nl/assets',
    models: {
      assets: 'all'
    },
    free: true,
    rateLimit: 'Public',
    noKeyRequired: true
  },

  ITCH_ASSETS: {
    name: 'Itch.io Assets',
    type: 'assets',
    endpoint: 'https://itch.io/game-assets/free',
    models: {
      assets: 'free'
    },
    free: true,
    rateLimit: 'Public',
    noKeyRequired: true
  }
};

export const ASSET_TYPES = {
  IMAGE: {
    name: 'Images/Sprites',
    extensions: ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg'],
    providers: ['STABILITY_FREE', 'REPLICATE_IMG', 'POLLINATIONS', 'CRAIYON', 'LEONARDO', 'IDEOGRAM', 'OPENGAMEART'],
    folder: 'assets/images'
  },
  MODEL_3D: {
    name: '3D Models',
    extensions: ['.obj', '.fbx', '.gltf', '.glb', '.blend'],
    providers: ['MESHY', 'TRIPO3D'],
    folder: 'assets/models'
  },
  AUDIO: {
    name: 'Audio/Music',
    extensions: ['.mp3', '.wav', '.ogg', '.m4a'],
    providers: ['ELEVENLABS_FREE', 'FAKEYOU', 'FREESOUND', 'SUNO_FREE', 'MUBERT', 'UBERDUCK'],
    folder: 'assets/sounds'
  },
  CODE: {
    name: 'Code',
    extensions: ['.js', '.ts', '.py', '.cs', '.cpp', '.gd'],
    providers: ['GROQ', 'DEEPINFRA', 'TOGETHER', 'HUGGINGFACE', 'OPENAI', 'ANTHROPIC', 'GOOGLE_GEMINI', 'COHERE', 'PERPLEXITY', 'CEREBRAS'],
    folder: 'src'
  },
  LIBRARY: {
    name: 'Libraries',
    extensions: ['.js', '.css'],
    providers: ['JSDELIVR', 'CDNJS'],
    folder: 'libs'
  }
};

export const COLLABORATIVE_MODE = {
  ORCHESTRATOR: {
    name: 'AI Orchestrator',
    role: 'Coordena e distribui tarefas entre IAs',
    provider: 'GROQ',
    systemPrompt: `You are an AI orchestrator. Analyze game development requests and:
1. Break down into subtasks (code, assets, libraries)
2. Assign best AI for each task
3. Coordinate responses
4. Ensure consistency across components`
  },
  
  CODE_SPECIALIST: {
    name: 'Code Specialist',
    role: 'Gera codigo de jogo otimizado',
    providers: ['GROQ', 'DEEPINFRA', 'TOGETHER', 'OPENAI', 'ANTHROPIC', 'GOOGLE_GEMINI', 'COHERE', 'PERPLEXITY', 'CEREBRAS', 'OPENROUTER', 'MISTRAL_API', 'FIREWORKS', 'OLLAMA_LOCAL', 'LMSTUDIO_LOCAL'],
    systemPrompt: 'You are an expert game developer. Generate clean, optimized, production-ready code.'
  },
  
  ASSET_SPECIALIST: {
    name: 'Asset Specialist',
    role: 'Gera e encontra assets',
    providers: ['STABILITY_FREE', 'POLLINATIONS', 'LEONARDO', 'IDEOGRAM', 'OPENGAMEART', 'FREESOUND'],
    systemPrompt: 'You are an expert in game assets. Find or generate sprites, sounds, and models.'
  },
  
  ARCHITECTURE_SPECIALIST: {
    name: 'Architecture Specialist',
    role: 'Define estrutura e organizacao',
    providers: ['GROQ', 'TOGETHER', 'ANTHROPIC'],
    systemPrompt: 'You are a software architect. Design clean project structures and suggest best libraries.'
  },
  
  LIBRARY_FINDER: {
    name: 'Library Finder',
    role: 'Encontra bibliotecas e frameworks',
    providers: ['SERPER', 'BRAVE_SEARCH', 'TAVILY', 'JSDELIVR', 'CDNJS'],
    systemPrompt: 'You find the best libraries and frameworks for game development tasks.'
  },

  DEBUG_SPECIALIST: {
    name: 'Debug Specialist',
    role: 'Analisa e corrige bugs no codigo',
    providers: ['GROQ', 'ANTHROPIC', 'OPENAI'],
    systemPrompt: 'You are an expert debugger. Analyze code for bugs, performance issues, and suggest fixes.'
  },

  OPTIMIZER: {
    name: 'Performance Optimizer',
    role: 'Otimiza codigo e assets',
    providers: ['GROQ', 'DEEPINFRA', 'TOGETHER'],
    systemPrompt: 'You optimize game code for performance, reduce bundle size, and improve loading times.'
  }
};

export const PROJECT_STRUCTURE = {
  WEB_GAME: {
    folders: [
      'src',
      'src/scenes',
      'src/entities',
      'src/systems',
      'src/utils',
      'assets',
      'assets/images',
      'assets/sprites',
      'assets/sounds',
      'assets/music',
      'assets/fonts',
      'libs',
      'docs'
    ],
    files: {
      'index.html': 'HTML template',
      'src/main.js': 'Entry point',
      'src/config.js': 'Configuration',
      'README.md': 'Documentation',
      'package.json': 'Dependencies'
    }
  },
  
  UNITY: {
    folders: [
      'Assets',
      'Assets/Scripts',
      'Assets/Scenes',
      'Assets/Prefabs',
      'Assets/Materials',
      'Assets/Textures',
      'Assets/Audio',
      'Assets/Models',
      'ProjectSettings'
    ],
    files: {
      'README.md': 'Documentation',
      'Assets/Scripts/GameManager.cs': 'Main game manager'
    }
  },
  
  GODOT: {
    folders: [
      'scripts',
      'scenes',
      'assets',
      'assets/sprites',
      'assets/sounds',
      'assets/fonts',
      'resources'
    ],
    files: {
      'project.godot': 'Project file',
      'README.md': 'Documentation'
    }
  },
  
  PYTHON: {
    folders: [
      'src',
      'assets',
      'assets/images',
      'assets/sounds',
      'data',
      'docs'
    ],
    files: {
      'main.py': 'Entry point',
      'requirements.txt': 'Dependencies',
      'README.md': 'Documentation',
      'config.py': 'Configuration'
    }
  }
};

export const SUPPORTED_LANGUAGES = {
  UNITY: {
    name: 'Unity',
    languages: ['C#', 'JavaScript'],
    extensions: ['.cs', '.js'],
    frameworks: ['Unity Engine'],
    structure: 'UNITY'
  },
  UNREAL: {
    name: 'Unreal Engine',
    languages: ['C++', 'Blueprint'],
    extensions: ['.cpp', '.h', '.uasset'],
    frameworks: ['Unreal Engine'],
    structure: 'UNITY'
  },
  GODOT: {
    name: 'Godot',
    languages: ['GDScript', 'C#', 'C++'],
    extensions: ['.gd', '.cs', '.cpp'],
    frameworks: ['Godot Engine'],
    structure: 'GODOT'
  },
  WEB: {
    name: 'Web Games',
    languages: ['JavaScript', 'TypeScript', 'HTML5', 'CSS3'],
    extensions: ['.js', '.ts', '.html', '.css'],
    frameworks: ['Phaser', 'PixiJS', 'Three.js', 'Babylon.js', 'PlayCanvas', 'Kaboom', 'Excalibur', 'MelonJS'],
    structure: 'WEB_GAME'
  },
  PYTHON: {
    name: 'Python',
    languages: ['Python'],
    extensions: ['.py'],
    frameworks: ['Pygame', 'Panda3D', 'Arcade', 'Ursina', 'Pyglet'],
    structure: 'PYTHON'
  },
  JAVA: {
    name: 'Java',
    languages: ['Java'],
    extensions: ['.java'],
    frameworks: ['LibGDX', 'jMonkeyEngine', 'LWJGL'],
    structure: 'PYTHON'
  }
};

export const GAME_TYPES = {
  RPG: {
    name: 'RPG',
    codeProviders: ['GROQ', 'TOGETHER', 'ANTHROPIC'],
    assetProviders: ['STABILITY_FREE', 'OPENGAMEART', 'LEONARDO'],
    requiredAssets: ['character sprites', 'UI elements', 'inventory icons', 'dialogue boxes', 'tileset'],
    requiredLibraries: ['inventory system', 'dialogue system', 'save system', 'quest manager']
  },
  FPS: {
    name: 'FPS',
    codeProviders: ['DEEPINFRA', 'GROQ', 'OPENAI'],
    assetProviders: ['STABILITY_FREE', 'FREESOUND', 'MESHY'],
    requiredAssets: ['weapon models', 'crosshair', 'muzzle flash', 'hit markers', 'gun sounds', 'footsteps'],
    requiredLibraries: ['physics engine', 'raycasting', 'audio system', 'networking']
  },
  PLATFORMER: {
    name: 'Platformer',
    codeProviders: ['GROQ', 'DEEPINFRA', 'TOGETHER'],
    assetProviders: ['POLLINATIONS', 'OPENGAMEART', 'KENNEY'],
    requiredAssets: ['player sprite', 'tileset', 'background', 'coins', 'enemies', 'power-ups'],
    requiredLibraries: ['physics engine', 'collision detection', 'particle system']
  },
  PUZZLE: {
    name: 'Puzzle',
    codeProviders: ['TOGETHER', 'GROQ', 'COHERE'],
    assetProviders: ['POLLINATIONS', 'OPENGAMEART'],
    requiredAssets: ['puzzle pieces', 'UI elements', 'particle effects', 'icons'],
    requiredLibraries: ['grid system', 'tween library', 'state machine']
  },
  RACING: {
    name: 'Racing',
    codeProviders: ['GROQ', 'DEEPINFRA'],
    assetProviders: ['MESHY', 'STABILITY_FREE'],
    requiredAssets: ['vehicle models', 'track tiles', 'speedometer', 'engine sounds'],
    requiredLibraries: ['physics engine', 'input handling', 'AI pathfinding']
  },
  STRATEGY: {
    name: 'Strategy',
    codeProviders: ['ANTHROPIC', 'GROQ', 'TOGETHER'],
    assetProviders: ['LEONARDO', 'OPENGAMEART'],
    requiredAssets: ['unit sprites', 'building sprites', 'map tiles', 'UI elements', 'icons'],
    requiredLibraries: ['grid system', 'pathfinding', 'AI system', 'resource management']
  },
  SHOOTER: {
    name: 'Shooter',
    codeProviders: ['GROQ', 'DEEPINFRA'],
    assetProviders: ['POLLINATIONS', 'FREESOUND'],
    requiredAssets: ['player sprite', 'enemy sprites', 'bullets', 'explosions', 'power-ups'],
    requiredLibraries: ['collision detection', 'particle system', 'audio manager']
  },
  ADVENTURE: {
    name: 'Adventure',
    codeProviders: ['ANTHROPIC', 'GROQ'],
    assetProviders: ['STABILITY_FREE', 'OPENGAMEART'],
    requiredAssets: ['character sprites', 'environment tiles', 'items', 'NPCs'],
    requiredLibraries: ['dialogue system', 'inventory', 'save system', 'quest tracker']
  }
};

export default {
  AI_PROVIDERS,
  ASSET_TYPES,
  COLLABORATIVE_MODE,
  PROJECT_STRUCTURE,
  SUPPORTED_LANGUAGES,
  GAME_TYPES
};
