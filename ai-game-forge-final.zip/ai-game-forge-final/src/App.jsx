import React, { useState, useEffect } from 'react';
import { 
  Zap, Settings, Sparkles, Download, Upload, 
  Brain, Users, Play, Layers, Search, Image, Music, Box,
  MessageCircle, Bug, Globe, Wand2, FileCode, Palette
} from 'lucide-react';
import collaborativeAIService from './services/collaborativeAIService';
import advancedZipService from './services/advancedZipService';
import GamePlayer from './components/GamePlayer';
import AIAssistants from './components/AIAssistants';
import { AI_PROVIDERS, GAME_TYPES, SUPPORTED_LANGUAGES } from './config/aiConfig';
import './App.css';

function App() {
  const [selectedLanguage, setSelectedLanguage] = useState('JavaScript');
  const [selectedFramework, setSelectedFramework] = useState('Phaser');
  const [selectedGameType, setSelectedGameType] = useState('PLATFORMER');
  const [prompt, setPrompt] = useState('');
  const [projectName, setProjectName] = useState('MyAwesomeGame');
  const [projectFiles, setProjectFiles] = useState([]);
  const [collaborativeResult, setCollaborativeResult] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState([]);
  const [useCollaborativeMode, setUseCollaborativeMode] = useState(true);
  const [includeAssets, setIncludeAssets] = useState(true);
  const [includeLibraries, setIncludeLibraries] = useState(true);
  const [apiKeys, setApiKeys] = useState({});
  const [providerSettings, setProviderSettings] = useState({});
  const [showSettings, setShowSettings] = useState(false);
  const [activeTab, setActiveTab] = useState('generate');

  useEffect(() => {
    loadSavedSettings();
  }, []);

  const loadSavedSettings = () => {
    const savedKeys = localStorage.getItem('ai_api_keys');
    if (savedKeys) {
      setApiKeys(JSON.parse(savedKeys));
    }
    const savedSettings = localStorage.getItem('ai_provider_settings');
    if (savedSettings) {
      try { setProviderSettings(JSON.parse(savedSettings)); } catch { setProviderSettings({}); }
    }
  };

  const handleSaveApiKey = (provider, key) => {
    const newKeys = { ...apiKeys, [provider]: key };
    setApiKeys(newKeys);
    collaborativeAIService.saveApiKey(provider, key);
  };

  const handleSaveProviderSetting = (providerId, partial) => {
    const current = providerSettings[providerId] || {};
    const next = { ...current, ...partial };
    const all = { ...providerSettings, [providerId]: next };
    setProviderSettings(all);
    localStorage.setItem('ai_provider_settings', JSON.stringify(all));

    if (partial.apiKey !== undefined) {
      collaborativeAIService.saveApiKey(providerId, partial.apiKey);
    } else {
      collaborativeAIService.setProviderSetting(providerId, partial);
    }
  };

  const addProgress = (message) => {
    setGenerationProgress(prev => [...prev, {
      message,
      timestamp: new Date().toLocaleTimeString()
    }]);
  };

  const handleCollaborativeGenerate = async () => {
    if (!prompt.trim()) {
      alert('Por favor, descreva o que voce quer criar!');
      return;
    }

    setIsGenerating(true);
    setGenerationProgress([]);
    setCollaborativeResult(null);

    try {
      addProgress('Iniciando modo colaborativo...');
      
      const request = {
        description: prompt,
        gameType: selectedGameType,
        language: selectedLanguage,
        framework: selectedFramework,
        includeAssets,
        includeLibraries
      };

      addProgress('Orchestrator analisando requisicao...');
      
      const result = await collaborativeAIService.collaborativeGenerate(request);
      
      addProgress('Geracao concluida!');
      
      setCollaborativeResult(result);

      const files = [];

      if (result.code) {
        files.push({
          path: `src/main.${getFileExtension(selectedLanguage)}`,
          content: result.code.content,
          type: 'code',
          provider: result.code.provider
        });

        if (result.code.alternates) {
          result.code.alternates.forEach((alt, idx) => {
            files.push({
              path: `src/alternates/version_${idx + 1}.${getFileExtension(selectedLanguage)}`,
              content: alt.code,
              type: 'code',
              provider: alt.provider
            });
          });
        }
      }

      if (result.assets) {
        for (const asset of result.assets) {
          if (asset?.data?.url && asset?.type === 'image') {
            try {
              const r = await fetch('/api/fetch', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ url: asset.data.url })
              });
              const data = await r.json();
              if (r.ok && data?.base64) {
                files.push({
                  path: `${asset.folder || 'assets/images'}/${asset.name}.png`,
                  content: data.base64,
                  type: 'asset-binary',
                  encoding: 'base64',
                  meta: { contentType: data.contentType, sourceUrl: asset.data.url, provider: asset.data.provider || 'unknown' }
                });
              } else {
                files.push({
                  path: `${asset.folder || 'assets/images'}/${asset.name}_ref.txt`,
                  content: asset.data.url,
                  type: 'asset'
                });
              }
            } catch (e) {
              files.push({
                path: `${asset.folder || 'assets/images'}/${asset.name}_ref.txt`,
                content: asset.data.url,
                type: 'asset'
              });
            }
            continue;
          }

          if (asset?.data?.url && asset?.type === 'audio') {
            files.push({
              path: `${asset.folder || 'assets/sounds'}/${asset.name}_ref.txt`,
              content: asset.data.url,
              type: 'asset'
            });
            continue;
          }

          files.push({
            path: `${asset.folder || 'assets'}/${asset.name}.json`,
            content: JSON.stringify(asset.data, null, 2),
            type: 'asset'
          });
        }
      }

      if (result.libraries) {
        const libsInfo = result.libraries.map(lib => 
          `${lib.name}: ${lib.cdn?.url || 'N/A'}`
        ).join('\n');
        
        files.push({
          path: 'libs/README.md',
          content: libsInfo,
          type: 'library'
        });
      }

      setProjectFiles(files);
      
      alert(`Projeto gerado com sucesso!\n\nCodigo: ${result.code ? 'Sim' : 'Nao'}\nAssets: ${result.assets?.length || 0}\nBibliotecas: ${result.libraries?.length || 0}`);

      setActiveTab('player');

    } catch (error) {
      console.error('Erro na geracao colaborativa:', error);
      addProgress(`Erro: ${error.message}`);
      alert(`Erro: ${error.message}\n\nVerifique as chaves de API nas configuracoes.`);
    } finally {
      setIsGenerating(false);
    }
  };

  const getFileExtension = (language) => {
    const extensions = {
      'JavaScript': 'js',
      'TypeScript': 'ts',
      'Python': 'py',
      'C#': 'cs',
      'C++': 'cpp',
      'GDScript': 'gd'
    };
    return extensions[language] || 'txt';
  };

  const handleExportProject = async () => {
    if (!collaborativeResult && projectFiles.length === 0) {
      alert('Nenhum projeto para exportar!');
      return;
    }

    try {
      const blob = await advancedZipService.createOrganizedProject({
        projectName,
        language: selectedLanguage,
        framework: selectedFramework,
        gameType: selectedGameType,
        collaborativeResult,
        platform: 'WEB_GAME'
      });

      advancedZipService.downloadZip(blob, `${projectName}.zip`);
      alert('Projeto exportado com sucesso!');
    } catch (error) {
      console.error('Erro ao exportar:', error);
      alert('Erro ao exportar projeto: ' + error.message);
    }
  };

  const getProvidersByType = (type) => {
    return Object.entries(AI_PROVIDERS)
      .filter(([key, provider]) => provider.type === type)
      .map(([key, provider]) => ({
        id: key,
        ...provider,
        hasApiKey: !!apiKeys[key]
      }));
  };

  return (
    <div className="app">
      <header className="header">
        <div className="header-content">
          <div className="logo">
            <Brain size={32} className="logo-icon" />
            <div>
              <h1>AI Game Forge PRO</h1>
              <p className="tagline">Collaborative Multi-AI Game Development</p>
            </div>
          </div>
          <div className="header-actions">
            <button 
              className="btn btn-secondary"
              onClick={() => setShowSettings(!showSettings)}
            >
              <Settings size={20} />
              Configuracoes
            </button>
          </div>
        </div>
      </header>

      {showSettings && (
        <div className="modal-overlay" onClick={() => setShowSettings(false)}>
          <div className="modal modal-large" onClick={(e) => e.stopPropagation()}>
            <h2>Configuracoes de API</h2>
            
            <div className="settings-tabs">
              
              <div className="settings-tab">
                <h3>IAs de Codigo</h3>
                {getProvidersByType('code').map(provider => {
                  const st = providerSettings[provider.id] || {};
                  const isEnabled = st.enabled !== false;
                  const apiKeyVal = st.apiKey ?? apiKeys[provider.id] ?? '';
                  const baseUrlVal = st.baseUrl ?? provider.endpoint ?? '';
                  const modelVal = st.model ?? provider.models?.chat ?? provider.models?.fast ?? provider.models?.coding ?? '';
                  const showBaseUrl = provider.openAICompatible || ['CUSTOM_OPENAI','OLLAMA_LOCAL','LMSTUDIO_LOCAL'].includes(provider.id);
                  return (
                    <div key={provider.id} className="api-key-item">
                      <div className="provider-info">
                        <h4>{provider.name}</h4>
                        <span className={`badge ${provider.free ? 'badge-success' : 'badge-warning'}`}>
                          {provider.free ? 'Gratuito' : 'Pago'}
                        </span>
                        <span className="rate-limit">{provider.rateLimit}</span>
                      </div>

                      <div className="settings-row">
                        <label className="checkbox">
                          <input
                            type="checkbox"
                            checked={isEnabled}
                            onChange={(e) => handleSaveProviderSetting(provider.id, { enabled: e.target.checked })}
                          />
                          Ativo
                        </label>
                      </div>

                      {!provider.noKeyRequired && (
                        <input
                          type="password"
                          placeholder={`API Key para ${provider.name}`}
                          value={apiKeyVal}
                          onChange={(e) => handleSaveProviderSetting(provider.id, { apiKey: e.target.value })}
                          className="input"
                        />
                      )}

                      {showBaseUrl && (
                        <input
                          type="text"
                          placeholder="Base URL (OpenAI-compatible)"
                          value={baseUrlVal}
                          onChange={(e) => handleSaveProviderSetting(provider.id, { baseUrl: e.target.value })}
                          className="input"
                        />
                      )}

                      <input
                        type="text"
                        placeholder="Model (opcional)"
                        value={modelVal}
                        onChange={(e) => handleSaveProviderSetting(provider.id, { model: e.target.value })}
                        className="input"
                      />
                    </div>
                  );
                })}
              </div>

              <div className="settings-tab">
                <h3>IAs de Imagens</h3>
                {getProvidersByType('image').map(provider => (
                  <div key={provider.id} className="api-key-item">
                    <div className="provider-info">
                      <h4>{provider.name}</h4>
                      {provider.noKeyRequired ? (
                        <span className="badge badge-success">Sem API Key</span>
                      ) : (
                        <span className="badge badge-warning">API Key</span>
                      )}
                    </div>
                    {!provider.noKeyRequired && (
                      <input
                        type="password"
                        placeholder={`API Key para ${provider.name}`}
                        value={(providerSettings[provider.id]?.apiKey ?? apiKeys[provider.id] ?? '')}
                        onChange={(e) => handleSaveProviderSetting(provider.id, { apiKey: e.target.value })}
                        className="input"
                      />
                    )}
                  </div>
                ))}
              </div>

              <div className="settings-tab">
                <h3>Busca Web</h3>
                {getProvidersByType('search').map(provider => (
                  <div key={provider.id} className="api-key-item">
                    <div className="provider-info">
                      <h4>{provider.name}</h4>
                      {provider.noKeyRequired ? (
                        <span className="badge badge-success">Sem API Key</span>
                      ) : (
                        <span className="badge badge-warning">API Key</span>
                      )}
                    </div>
                    {!provider.noKeyRequired && (
                      <input
                        type="password"
                        placeholder={`API Key para ${provider.name}`}
                        value={(providerSettings[provider.id]?.apiKey ?? apiKeys[provider.id] ?? '')}
                        onChange={(e) => handleSaveProviderSetting(provider.id, { apiKey: e.target.value })}
                        className="input"
                      />
                    )}
                  </div>
                ))}
              </div>

              <div className="settings-tab">
                <h3>Audio e Musica</h3>
                {getProvidersByType('audio').map(provider => (
                  <div key={provider.id} className="api-key-item">
                    <div className="provider-info">
                      <h4>{provider.name}</h4>
                      {provider.noKeyRequired ? (
                        <span className="badge badge-success">Sem API Key</span>
                      ) : (
                        <span className="badge badge-warning">API Key</span>
                      )}
                    </div>
                    {!provider.noKeyRequired && (
                      <input
                        type="password"
                        placeholder={`API Key para ${provider.name}`}
                        value={(providerSettings[provider.id]?.apiKey ?? apiKeys[provider.id] ?? '')}
                        onChange={(e) => handleSaveProviderSetting(provider.id, { apiKey: e.target.value })}
                        className="input"
                      />
                    )}
                  </div>
                ))}
              </div>

              <div className="settings-tab">
                <h3>3D e Assets</h3>
                {getProvidersByType('3d').map(provider => (
                  <div key={provider.id} className="api-key-item">
                    <div className="provider-info">
                      <h4>{provider.name}</h4>
                      {provider.noKeyRequired ? (
                        <span className="badge badge-success">Sem API Key</span>
                      ) : (
                        <span className="badge badge-warning">API Key</span>
                      )}
                    </div>
                    {!provider.noKeyRequired && (
                      <input
                        type="password"
                        placeholder={`API Key para ${provider.name}`}
                        value={(providerSettings[provider.id]?.apiKey ?? apiKeys[provider.id] ?? '')}
                        onChange={(e) => handleSaveProviderSetting(provider.id, { apiKey: e.target.value })}
                        className="input"
                      />
                    )}
                  </div>
                ))}
                {getProvidersByType('assets').map(provider => (
                  <div key={provider.id} className="api-key-item">
                    <div className="provider-info">
                      <h4>{provider.name}</h4>
                      <span className="badge badge-success">Sem API Key</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="modal-actions">
              <button 
                className="btn btn-primary"
                onClick={() => setShowSettings(false)}
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="main-content">
        <aside className="sidebar">
          <div className="sidebar-section">
            <h3>Projeto</h3>
            <input
              type="text"
              value={projectName}
              onChange={(e) => setProjectName(e.target.value)}
              placeholder="Nome do projeto"
              className="input"
            />
          </div>

          <div className="sidebar-section">
            <h3>Linguagem</h3>
            <select 
              value={selectedLanguage}
              onChange={(e) => setSelectedLanguage(e.target.value)}
              className="select"
            >
              {Object.entries(SUPPORTED_LANGUAGES).map(([key, lang]) => (
                <optgroup key={key} label={lang.name}>
                  {lang.languages.map(l => (
                    <option key={l} value={l}>{l}</option>
                  ))}
                </optgroup>
              ))}
            </select>
          </div>

          <div className="sidebar-section">
            <h3>Framework</h3>
            <input
              type="text"
              value={selectedFramework}
              onChange={(e) => setSelectedFramework(e.target.value)}
              placeholder="Ex: Phaser, Unity"
              className="input"
            />
          </div>

          <div className="sidebar-section">
            <h3>Tipo de Jogo</h3>
            <select 
              value={selectedGameType}
              onChange={(e) => setSelectedGameType(e.target.value)}
              className="select"
            >
              {Object.entries(GAME_TYPES).map(([key, type]) => (
                <option key={key} value={key}>{type.name}</option>
              ))}
            </select>
          </div>

          <div className="sidebar-section">
            <h3>Modo Colaborativo</h3>
            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={useCollaborativeMode}
                onChange={(e) => setUseCollaborativeMode(e.target.checked)}
              />
              <Users size={16} />
              Usar todas as IAs juntas
            </label>

            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={includeAssets}
                onChange={(e) => setIncludeAssets(e.target.checked)}
              />
              <Image size={16} />
              Gerar assets
            </label>

            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={includeLibraries}
                onChange={(e) => setIncludeLibraries(e.target.checked)}
              />
              <Box size={16} />
              Buscar bibliotecas
            </label>
          </div>

          <div className="sidebar-section">
            <h3>Exportar</h3>
            <button 
              className="btn btn-success btn-large"
              onClick={handleExportProject}
              disabled={projectFiles.length === 0}
            >
              <Download size={18} />
              Exportar ZIP
            </button>
          </div>
        </aside>

        <div className="main-area">
          <div className="tabs">
            <button
              className={`tab ${activeTab === 'generate' ? 'active' : ''}`}
              onClick={() => setActiveTab('generate')}
            >
              <Sparkles size={16} />
              Gerar
            </button>
            <button
              className={`tab ${activeTab === 'player' ? 'active' : ''}`}
              onClick={() => setActiveTab('player')}
            >
              <Play size={16} />
              Player
            </button>
            <button
              className={`tab ${activeTab === 'files' ? 'active' : ''}`}
              onClick={() => setActiveTab('files')}
            >
              <Layers size={16} />
              Arquivos ({projectFiles.length})
            </button>
            <button
              className={`tab ${activeTab === 'assist' ? 'active' : ''}`}
              onClick={() => setActiveTab('assist')}
            >
              <Brain size={16} />
              Assistentes
            </button>
          </div>

          {activeTab === 'generate' && (
            <div className="tab-content">
              <div className="prompt-section">
                <h3>Descreva seu jogo</h3>
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="Exemplo: Criar um jogo platformer 2D onde o jogador pode pular, correr e coletar moedas. Incluir sistema de pontuacao e inimigos que patrulham."
                  className="prompt-input"
                  rows={8}
                />
                
                <button 
                  className="btn btn-primary btn-large"
                  onClick={handleCollaborativeGenerate}
                  disabled={isGenerating}
                >
                  {isGenerating ? (
                    <>
                      <Sparkles size={20} className="spin" />
                      Gerando com {useCollaborativeMode ? 'Multiplas IAs' : 'IA Principal'}...
                    </>
                  ) : (
                    <>
                      <Zap size={20} />
                      {useCollaborativeMode ? 'Gerar com Todas as IAs' : 'Gerar Codigo'}
                    </>
                  )}
                </button>
              </div>

              {generationProgress.length > 0 && (
                <div className="progress-section">
                  <h3>Progresso</h3>
                  <div className="progress-list">
                    {generationProgress.map((item, idx) => (
                      <div key={idx} className="progress-item">
                        <span className="progress-time">{item.timestamp}</span>
                        <span className="progress-message">{item.message}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'player' && (
            <div className="tab-content">
              <GamePlayer 
                projectFiles={projectFiles}
                projectName={projectName}
                framework={selectedFramework}
              />
            </div>
          )}

          {activeTab === 'files' && (
            <div className="tab-content">
              <div className="files-section">
                <div className="files-header">
                  <h3>Arquivos do Projeto</h3>
                  <button 
                    className="btn btn-success"
                    onClick={handleExportProject}
                    disabled={projectFiles.length === 0}
                  >
                    <Download size={16} />
                    Exportar ZIP
                  </button>
                </div>

                {projectFiles.length === 0 ? (
                  <div className="empty-state">
                    <FileCode size={48} />
                    <p>Nenhum arquivo gerado ainda.</p>
                    <p className="text-muted">Use a aba "Gerar" para criar seu jogo.</p>
                  </div>
                ) : (
                  <div className="files-grid">
                    {projectFiles.map((file, idx) => (
                      <div key={idx} className="file-card">
                        <div className="file-header">
                          <span className="file-path">{file.path}</span>
                          {file.provider && (
                            <span className="file-badge">{file.provider}</span>
                          )}
                        </div>
                        <pre className="file-content">
                          {file.content.substring(0, 300)}
                          {file.content.length > 300 && '...'}
                        </pre>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'assist' && (
            <div className="tab-content">
              <AIAssistants
                description={prompt}
                gameType={selectedGameType}
                framework={selectedFramework}
                language={selectedLanguage}
                apiKeys={apiKeys}
              />
            </div>
          )}
        </div>
      </div>

      <footer className="footer">
        <p>AI Game Forge PRO - Powered by Multiple AI Providers</p>
      </footer>
    </div>
  );
}

export default App;
