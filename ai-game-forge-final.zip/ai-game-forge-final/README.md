# 🎮 AI GAME FORGE ULTIMATE

## 🌟 VERSÃO COMPLETA - TODAS AS FUNCIONALIDADES

**Plataforma Profissional de Desenvolvimento de Jogos com IA**

### ⚡ INSTALAÇÃO

```bash
npm install
npm run dev
```

---

## ✨ FUNCIONALIDADES COMPLETAS

### 🤖 MODO DUAL: Individual + Colaborativo

#### MODO 1: Individual (Escolher 1 IA)
```
✅ Selecione provedor específico
✅ Gere código com IA escolhida
✅ Veja estatísticas de cada provedor
✅ Compare resultados de diferentes IAs
✅ Fallback automático se falhar
```

#### MODO 2: Colaborativo (Todas IAs Juntas)
```
✅ Orchestrator AI coordena tudo
✅ Code AI gera código do jogo
✅ Asset AI gera sprites/imagens
✅ Library Finder busca bibliotecas
✅ Web Search pesquisa recursos
✅ Consolida tudo em projeto organizado
```

**Você escolhe qual usar!**

---

### 💻 GERAÇÃO DE CÓDIGO

**5 IAs Integradas:**
- Groq (Ultra-rápido) ⚡ RECOMENDADO
- DeepInfra (Tier ilimitado)
- Together AI (CodeLlama)
- HuggingFace (Mistral, StarCoder)
- Cohere (Command)

**Suporte a:**
- 8+ Linguagens (JavaScript, TypeScript, Python, C#, C++, GDScript, Java, Rust)
- 12+ Frameworks (Phaser, PixiJS, Three.js, Unity, Godot, Pygame, etc)
- 10 Tipos de Jogos (Platformer, FPS, RPG, Puzzle, Racing, etc)

**Recursos:**
- Sistema de fallback inteligente
- Geração de versões alternativas
- Prompts otimizados por tipo de jogo
- Código limpo e comentado

---

### 🎨 GERAÇÃO DE ASSETS

**3 IAs de Imagens:**
- Pollinations AI (SEM API KEY!) ⭐
- Stability AI (via HuggingFace)
- Replicate

**Features:**
- Geração automática de sprites
- Baseado no tipo de jogo
- URLs diretas para download
- Prompts otimizados
- Múltiplos estilos

---

### 🔍 BUSCA WEB INTEGRADA

**2 Engines:**
- DuckDuckGo (SEM API KEY!)
- Serper (Google Search API)

**Busca Automática de:**
- Tutoriais de jogos
- Bibliotecas JavaScript
- Assets gratuitos
- Documentação de frameworks
- Exemplos de código

---

### 🎮 GAME PLAYER INTEGRADO

**Recursos do Player:**
- ▶️ Executar jogos HTML5 dentro do app
- 🔄 Reiniciar jogo
- ⏹️ Parar execução
- ⛶ Modo fullscreen
- 💾 Download HTML standalone
- </> Ver código-fonte
- 🐛 Console de debug integrado

**Suporta:**
- Phaser, PixiJS, Three.js, Babylon.js
- Kaboom, PlayCanvas
- Canvas puro
- Qualquer jogo HTML5

**Live Preview:**
- Testa sem sair do app
- Vê erros em tempo real
- Logs integrados

---

### 📦 MANIPULAÇÃO DE ZIP

**Criar:**
- Projetos organizados profissionalmente
- Estrutura por plataforma (Web, Unity, Godot, Python)
- README personalizado
- package.json configurado
- .gitignore incluído

**Ler:**
- Analisa ZIPs existentes
- Detecta tipo de arquivos
- Categoriza automaticamente

**Modificar:**
- Adiciona/remove arquivos
- Reorganiza estrutura
- Atualiza e re-exporta

**Auto-Organização:**
- Separa código/assets/libs
- Cria pastas apropriadas
- Nomeia arquivos corretamente

---

### 💾 EDITOR DE ARQUIVOS

**Features:**
- Múltiplos arquivos abertos
- Syntax highlighting (Prism.js)
- Salvar/Carregar
- Delete arquivos
- Adicionar novos
- Download individual
- Visualização de código

**Organização:**
- Lista de arquivos lateral
- Filtro por tipo
- Badges com provedor usado
- Tamanho do arquivo

---

### ⚙️ CONFIGURAÇÃO DE APIs

**Gestão Completa:**
- Salva keys localmente (localStorage)
- Múltiplos provedores simultaneamente
- Teste de conectividade
- Estatísticas de uso por provedor
- Rate limits visíveis
- Indicadores de status

**Provedores:**
- 5 Code AIs
- 3 Image AIs
- 2 Search AIs
- **Total: 10+ APIs**

---

### 📊 ESTATÍSTICAS

**Monitora:**
- Requests por provedor
- Taxa de sucesso/falha
- Tempo médio de resposta
- Uso total
- Histórico de geração

**Exibe:**
- Gráficos por IA
- Comparação de performance
- Recomendações

---

### 🎯 GESTÃO DE PROJETOS

**Recursos:**
- Nome personalizado
- Múltiplos arquivos
- Organização automática por tipo
- Metadados do projeto
- Histórico de modificações

**Exportação:**
- ZIP profissional
- README gerado
- Estrutura otimizada
- Todos os assets incluídos
- Pronto para executar

**Estrutura Gerada:**
```
MeuJogo/
├── src/              ← Código
├── assets/
│   ├── images/      ← Sprites
│   ├── sounds/      ← Áudio
│   └── models/      ← 3D
├── libs/            ← Bibliotecas
├── index.html       ← Pronto!
├── package.json
├── README.md
└── .gitignore
```

---

### 🎨 INTERFACE COMPLETA

**3 Abas Principais:**

1. **🚀 GERAR**
   - Configurar projeto
   - Modo individual/colaborativo
   - Prompt de geração
   - Ver progresso
   - Opções avançadas

2. **▶️ PLAYER**
   - Executar jogo
   - Debug console
   - Controles de reprodução
   - Fullscreen
   - Download

3. **📁 ARQUIVOS**
   - Lista de todos os arquivos
   - Editar código
   - Salvar/Deletar
   - Exportar ZIP

**Sidebar:**
- Configurações do projeto
- Linguagem/Framework
- Tipo de jogo
- Modo de geração
- Opções de assets

**Features UI:**
- Dark theme profissional
- Responsive design
- Atalhos de teclado
- Drag & drop (futuramente)
- Animações suaves

---

## 🚀 QUICK START

### 1. Instalar
```bash
cd ai-game-forge-ultimate
npm install
```

### 2. Iniciar
```bash
npm run dev
```

### 3. Configurar API
```
1. Abra: https://console.groq.com
2. Crie conta grátis
3. Copie API key
4. No app: ⚙️ Configurações → Cole
```

### 4. Criar Primeiro Jogo

**MODO INDIVIDUAL:**
```
1. Selecione provedor: Groq
2. Digite: "Criar jogo de pong"
3. Clique: Gerar Código
4. Aguarde ~10s
5. Tab Player → Jogar
```

**MODO COLABORATIVO:**
```
1. Ative: ✅ Modo Colaborativo
2. Digite: "Criar jogo platformer com física"
3. Clique: Gerar com Todas as IAs
4. Aguarde ~30s
5. Tab Player → Jogar
```

---

## 📋 EXEMPLOS DE USO

### Exemplo 1: Código Simples
```
Modo: Individual (Groq)
Prompt: "Sistema de movimentação 2D com WASD"
Tempo: ~10s
Resultado: 1 arquivo .js
```

### Exemplo 2: Projeto Completo
```
Modo: Colaborativo
Prompt: "Jogo platformer com moedas e inimigos"
Tempo: ~30s
Resultado: 
- Código principal
- Sprites (player, enemy, coin)
- Biblioteca Phaser
- HTML pronto
```

### Exemplo 3: Múltiplas Versões
```
Modo: Individual
1. Gere com Groq
2. Gere com DeepInfra
3. Compare versões em alternates/
4. Escolha a melhor
```

---

## 🔧 TECNOLOGIAS

**Frontend:**
- React 18
- Vite 5
- Lucide Icons
- Prism.js (syntax highlighting)

**Integração:**
- Axios (HTTP requests)
- JSZip (manipulação ZIP)

**APIs:**
- 5 Code AIs
- 3 Image AIs
- 2 Search engines
- CDN para bibliotecas

**Sem Dependências Nativas:**
- ✅ Puro JavaScript
- ✅ Funciona Windows/Mac/Linux
- ✅ Sem compilação C++
- ✅ Instalação rápida

---

## 💡 DICAS PRO

**Prompts Efetivos:**
- Seja específico
- Mencione números (velocidade, tamanho, etc)
- Descreva comportamentos
- Inclua framework se souber

**Bom:** "Criar personagem que pula 150px usando espaço"
**Ruim:** "fazer jogo"

**Modo Individual vs Colaborativo:**
- Individual: Mais rápido, 1 IA, código direto
- Colaborativo: Mais completo, múltiplas IAs, projeto organizado

**Performance:**
- Groq: Mais rápido (5-15s)
- Colaborativo: Mais completo (30-60s)
- DeepInfra: Sem limites

---

## ⚡ COMPATIBILIDADE

**Sistemas:**
- ✅ Windows 10/11
- ✅ macOS 10.15+
- ✅ Linux (Ubuntu, Fedora, etc)

**Node.js:**
- ✅ 18.x
- ✅ 20.x
- ✅ 22.x

**Navegadores:**
- ✅ Chrome/Edge 100+
- ✅ Firefox 100+
- ✅ Safari 15+

---

## 🎁 INCLUÍDO

- ✅ Código-fonte completo
- ✅ Documentação em PT-BR
- ✅ Guias de instalação
- ✅ Exemplos de prompts
- ✅ Troubleshooting
- ✅ TODAS as funcionalidades

---

## 📄 LICENÇA

MIT - Use livremente, modifique, distribua!

---

## 🌟 RESUMO DAS FUNCIONALIDADES

✅ **10+ IAs integradas** (código, imagens, busca)
✅ **Modo individual** (escolher 1 IA)
✅ **Modo colaborativo** (todas IAs juntas)
✅ **Game Player** integrado
✅ **Geração de assets** com IA
✅ **Busca web** automática
✅ **Manipulação ZIP** completa
✅ **Editor** de código
✅ **Syntax highlighting**
✅ **8+ linguagens** suportadas
✅ **12+ frameworks**
✅ **10 tipos** de jogos
✅ **Auto-organização** de projetos
✅ **Exportação** profissional
✅ **Estatísticas** de uso
✅ **100% Windows** compatível

---

**VERSÃO ULTIMATE - Nada foi removido, tudo foi melhorado!**

**Desenvolvido com ❤️ para a comunidade de game dev**


## Rodar com proxy de API (recomendado)

Este app agora inclui um servidor local (Express) para evitar erros de CORS ao chamar APIs de IA.

```bash
npm install
npm run dev:full
```

- Frontend: http://localhost:3000
- API (proxy): http://localhost:8787/api/health

As chaves continuam sendo configuradas na UI (Configurações) e enviadas para o proxy local em cada chamada.
