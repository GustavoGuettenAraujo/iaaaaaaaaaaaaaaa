import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import fetch from "node-fetch";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: "20mb" }));

app.get("/api/health", (req, res) => {
  res.json({ ok: true, service: "ai-game-forge-api", time: new Date().toISOString() });
});

app.post("/api/chat", async (req, res) => {
  try {
    const {
      provider,
      apiKey,
      baseUrl,
      model,
      messages,
      max_tokens = 2000,
      temperature = 0.7,
      noAuth = false
    } = req.body || {};

    if (!provider) return res.status(400).json({ error: "provider is required" });
    if (!noAuth && !apiKey) return res.status(400).json({ error: "apiKey is required" });
    if (!model) return res.status(400).json({ error: "model is required" });
    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: "messages must be a non-empty array" });
    }

    const resolvedBaseUrl = (() => {
      if (provider === "GROQ") return "https://api.groq.com/openai/v1";
      if (provider === "DEEPINFRA") return "https://api.deepinfra.com/v1/openai";
      if (provider === "TOGETHER") return "https://api.together.xyz/v1";
      if (provider === "OPENAI") return "https://api.openai.com/v1";
      if (provider === "OPENROUTER") return "https://openrouter.ai/api/v1";
      if (provider === "FIREWORKS") return "https://api.fireworks.ai/inference/v1";
      if (provider === "MISTRAL_API") return "https://api.mistral.ai/v1";
      if (provider === "PERPLEXITY") return "https://api.perplexity.ai";
      if (provider === "CEREBRAS") return "https://api.cerebras.ai/v1";
      if (provider === "CUSTOM_OPENAI") return baseUrl;
      if (provider === "OLLAMA_LOCAL") return baseUrl || "http://localhost:11434/v1";
      if (provider === "LMSTUDIO_LOCAL") return baseUrl || "http://localhost:1234/v1";
      return baseUrl;
    })();

    if (!resolvedBaseUrl) return res.status(400).json({ error: "baseUrl is required for this provider" });

    const url = `${resolvedBaseUrl.replace(/\/$/, "")}/chat/completions`;

    const headers = {
      "Content-Type": "application/json"
    };

    if (!noAuth && apiKey) {
      headers["Authorization"] = `Bearer ${apiKey}`;
    }

    if (provider === "OPENROUTER") {
      headers["HTTP-Referer"] = "https://ai-game-forge.replit.app";
      headers["X-Title"] = "AI Game Forge";
    }

    const r = await fetch(url, {
      method: "POST",
      headers,
      body: JSON.stringify({
        model,
        messages,
        max_tokens,
        temperature
      })
    });

    const data = await r.json();

    if (!r.ok) {
      return res.status(r.status).json({ error: data?.error || data || "provider_error" });
    }

    const content = data?.choices?.[0]?.message?.content ?? "";
    return res.json({ content, raw: data });
  } catch (err) {
    return res.status(500).json({ error: String(err?.message || err) });
  }
});

app.post("/api/gemini", async (req, res) => {
  try {
    const { apiKey, model = "gemini-2.0-flash-exp", prompt, maxTokens = 2000 } = req.body || {};
    if (!apiKey) return res.status(400).json({ error: "apiKey is required" });
    if (!prompt) return res.status(400).json({ error: "prompt is required" });

    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
    
    const r = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: {
          maxOutputTokens: maxTokens,
          temperature: 0.7
        }
      })
    });

    const data = await r.json();
    if (!r.ok) return res.status(r.status).json({ error: data?.error || data || "gemini_error" });

    const content = data?.candidates?.[0]?.content?.parts?.[0]?.text || "";
    return res.json({ content, raw: data });
  } catch (err) {
    return res.status(500).json({ error: String(err?.message || err) });
  }
});

app.post("/api/anthropic", async (req, res) => {
  try {
    const { apiKey, model = "claude-3-5-sonnet-20241022", prompt, maxTokens = 2000 } = req.body || {};
    if (!apiKey) return res.status(400).json({ error: "apiKey is required" });
    if (!prompt) return res.status(400).json({ error: "prompt is required" });

    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model,
        max_tokens: maxTokens,
        messages: [{ role: "user", content: prompt }]
      })
    });

    const data = await r.json();
    if (!r.ok) return res.status(r.status).json({ error: data?.error || data || "anthropic_error" });

    const content = data?.content?.[0]?.text || "";
    return res.json({ content, raw: data });
  } catch (err) {
    return res.status(500).json({ error: String(err?.message || err) });
  }
});

app.post("/api/cohere", async (req, res) => {
  try {
    const { apiKey, model = "command-r-plus", prompt, maxTokens = 2000 } = req.body || {};
    if (!apiKey) return res.status(400).json({ error: "apiKey is required" });
    if (!prompt) return res.status(400).json({ error: "prompt is required" });

    const r = await fetch("https://api.cohere.ai/v1/chat", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model,
        message: prompt,
        max_tokens: maxTokens
      })
    });

    const data = await r.json();
    if (!r.ok) return res.status(r.status).json({ error: data?.message || data || "cohere_error" });

    const content = data?.text || "";
    return res.json({ content, raw: data });
  } catch (err) {
    return res.status(500).json({ error: String(err?.message || err) });
  }
});

app.post("/api/hf", async (req, res) => {
  try {
    const { apiKey, model, inputs, parameters, noAuth = false } = req.body || {};
    if (!noAuth && !apiKey) return res.status(400).json({ error: "apiKey is required" });
    if (!model) return res.status(400).json({ error: "model is required" });
    if (!inputs) return res.status(400).json({ error: "inputs is required" });

    const url = `https://api-inference.huggingface.co/models/${model}`;
    const r = await fetch(url, {
      method: "POST",
      headers: {
        ...(noAuth ? {} : { "Authorization": `Bearer ${apiKey}` }),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ inputs, parameters: parameters || {} })
    });
    const data = await r.json();
    if (!r.ok) return res.status(r.status).json({ error: data?.error || data || "hf_error" });
    return res.json({ data });
  } catch (err) {
    return res.status(500).json({ error: String(err?.message || err) });
  }
});

app.post("/api/replicate", async (req, res) => {
  try {
    const { apiKey, versionOrModel, input, noAuth = false } = req.body || {};
    if (!noAuth && !apiKey) return res.status(400).json({ error: "apiKey is required" });
    if (!versionOrModel) return res.status(400).json({ error: "versionOrModel is required" });
    if (!input) return res.status(400).json({ error: "input is required" });

    const create = await fetch("https://api.replicate.com/v1/predictions", {
      method: "POST",
      headers: {
        "Authorization": `Token ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        version: versionOrModel,
        input
      })
    });
    const created = await create.json();
    if (!create.ok) return res.status(create.status).json({ error: created?.detail || created || "replicate_error" });

    let pred = created;
    const id = pred?.id;
    if (!id) return res.status(500).json({ error: "Replicate returned no prediction id" });

    const maxPolls = 30;
    for (let i = 0; i < maxPolls; i++) {
      if (pred?.status === "succeeded" || pred?.status === "failed" || pred?.status === "canceled") break;
      await new Promise(r => setTimeout(r, 1500));
      const pr = await fetch(`https://api.replicate.com/v1/predictions/${id}`, {
        headers: { "Authorization": `Token ${apiKey}` }
      });
      pred = await pr.json();
      if (!pr.ok) return res.status(pr.status).json({ error: pred?.detail || pred || "replicate_poll_error" });
    }

    if (pred?.status !== "succeeded") {
      return res.status(500).json({ error: "Replicate prediction did not succeed", status: pred?.status, raw: pred });
    }

    return res.json({ output: pred?.output, raw: pred });
  } catch (err) {
    return res.status(500).json({ error: String(err?.message || err) });
  }
});

app.post("/api/web/search", async (req, res) => {
  try {
    const { query, provider = "DUCKDUCKGO", apiKey, limit = 8 } = req.body || {};
    if (!query) return res.status(400).json({ error: "query is required" });

    if (provider === "DUCKDUCKGO") {
      const url = `https://duckduckgo.com/html/?q=${encodeURIComponent(query)}&kl=us-en`;
      const r = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0" } });
      const html = await r.text();

      const results = [];
      const re = /<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>[\s\S]*?<a[^>]+class="result__snippet"[^>]*>([\s\S]*?)<\/a>/g;
      let m;
      while ((m = re.exec(html)) && results.length < limit) {
        const rawUrl = m[1];
        const title = stripTags(m[2]);
        const snippet = stripTags(m[3]);
        results.push({ title, url: rawUrl, snippet });
      }

      if (results.length === 0) {
        const re2 = /<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/g;
        let m2;
        while ((m2 = re2.exec(html)) && results.length < limit) {
          results.push({ title: stripTags(m2[2]), url: m2[1], snippet: "" });
        }
      }

      return res.json({ provider, query, results });
    }

    if (provider === "SERPER") {
      if (!apiKey) return res.status(400).json({ error: "apiKey is required for SERPER" });
      const r = await fetch("https://google.serper.dev/search", {
        method: "POST",
        headers: { "X-API-KEY": apiKey, "Content-Type": "application/json" },
        body: JSON.stringify({ q: query, num: Math.min(Number(limit) || 8, 10) })
      });
      const data = await r.json();
      if (!r.ok) return res.status(r.status).json({ error: data?.message || data || "serper_error" });

      const results = (data?.organic || []).slice(0, limit).map(it => ({
        title: it.title,
        url: it.link,
        snippet: it.snippet
      }));
      return res.json({ provider, query, results, raw: data });
    }

    if (provider === "BRAVE_SEARCH") {
      if (!apiKey) return res.status(400).json({ error: "apiKey is required for BRAVE_SEARCH" });
      const r = await fetch(`https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(query)}&count=${Math.min(Number(limit) || 8, 20)}`, {
        headers: { "Accept": "application/json", "X-Subscription-Token": apiKey }
      });
      const data = await r.json();
      if (!r.ok) return res.status(r.status).json({ error: data?.message || data || "brave_error" });

      const results = (data?.web?.results || []).slice(0, limit).map(it => ({
        title: it.title,
        url: it.url,
        snippet: it.description
      }));
      return res.json({ provider, query, results, raw: data });
    }

    if (provider === "TAVILY") {
      if (!apiKey) return res.status(400).json({ error: "apiKey is required for TAVILY" });
      const r = await fetch("https://api.tavily.com/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ api_key: apiKey, query, max_results: limit })
      });
      const data = await r.json();
      if (!r.ok) return res.status(r.status).json({ error: data?.error || data || "tavily_error" });

      const results = (data?.results || []).slice(0, limit).map(it => ({
        title: it.title,
        url: it.url,
        snippet: it.content
      }));
      return res.json({ provider, query, results, raw: data });
    }

    return res.status(400).json({ error: `Unknown provider: ${provider}` });
  } catch (err) {
    return res.status(500).json({ error: String(err?.message || err) });
  }
});

app.post("/api/github/search", async (req, res) => {
  try {
    const { query, token, limit = 8 } = req.body || {};
    if (!query) return res.status(400).json({ error: "query is required" });

    const url = `https://api.github.com/search/repositories?q=${encodeURIComponent(query)}&per_page=${Math.min(Number(limit) || 8, 20)}&sort=stars&order=desc`;
    const r = await fetch(url, {
      headers: {
        "Accept": "application/vnd.github+json",
        ...(token ? { "Authorization": `Bearer ${token}` } : {})
      }
    });
    const data = await r.json();
    if (!r.ok) return res.status(r.status).json({ error: data?.message || data || "github_error" });

    const results = (data?.items || []).map(it => ({
      full_name: it.full_name,
      html_url: it.html_url,
      description: it.description,
      stars: it.stargazers_count,
      language: it.language,
      topics: it.topics || []
    }));

    return res.json({ query, results, raw: { total_count: data?.total_count } });
  } catch (err) {
    return res.status(500).json({ error: String(err?.message || err) });
  }
});

function normalizeAssetType(type) {
  const t = String(type || "").toLowerCase();
  if (t.includes("audio") || t.includes("sound")) return "audio";
  if (t.includes("3d") || t.includes("model")) return "3d";
  return "image";
}

app.post("/api/fetch", async (req, res) => {
  try {
    const { url } = req.body || {};
    if (!url) return res.status(400).json({ error: "url is required" });
    const u = String(url);
    if (!/^https?:\/\//i.test(u)) return res.status(400).json({ error: "only http/https allowed" });

    const r = await fetch(u, { headers: { "User-Agent": "Mozilla/5.0" } });
    if (!r.ok) return res.status(r.status).json({ error: `fetch failed (${r.status})` });

    const contentType = r.headers.get("content-type") || "application/octet-stream";
    const isAllowed = /^image\//i.test(contentType) || /^audio\//i.test(contentType) || contentType === "application/octet-stream";
    if (!isAllowed) return res.status(415).json({ error: `unsupported content-type: ${contentType}` });

    const buf = await r.arrayBuffer();
    const maxBytes = 10 * 1024 * 1024;
    if (buf.byteLength > maxBytes) return res.status(413).json({ error: "file too large" });

    const b64 = Buffer.from(buf).toString("base64");
    return res.json({ url: u, contentType, base64: b64 });
  } catch (err) {
    return res.status(500).json({ error: String(err?.message || err) });
  }
});

app.post("/api/assets/search", async (req, res) => {
  try {
    const { query, type = "image", limit = 10 } = req.body || {};
    if (!query) return res.status(400).json({ error: "query is required" });

    const assetType = normalizeAssetType(type);

    if (assetType === "image" || assetType === "audio") {
      const endpoint = assetType === "audio" ? "audio" : "images";
      const url = `https://api.openverse.engineering/v1/${endpoint}?q=${encodeURIComponent(query)}&page_size=${Math.min(Number(limit) || 10, 20)}`;
      const r = await fetch(url, { headers: { "Accept": "application/json" } });
      const data = await r.json();
      if (!r.ok) return res.status(r.status).json({ error: data?.detail || data || "openverse_error" });

      const results = (data?.results || []).slice(0, limit).map(it => ({
        title: it.title,
        url: it.url,
        creator: it.creator,
        license: it.license,
        license_url: it.license_url,
        source: it.foreign_landing_url || it.url,
        thumbnail: it.thumbnail || it.thumbnail_url,
        file: it.url
      }));

      return res.json({ provider: "OPENVERSE", query, type: assetType, results, raw: { result_count: data?.result_count } });
    }

    if (assetType === "3d") {
      const listUrl = "https://api.polyhaven.com/assets?t=model";
      const r = await fetch(listUrl, { headers: { "Accept": "application/json" } });
      const data = await r.json();
      if (!r.ok) return res.status(r.status).json({ error: data || "polyhaven_error" });

      const q = query.toLowerCase();
      const keys = Object.keys(data || {}).filter(k => k.toLowerCase().includes(q.split(" ")[0] || q)).slice(0, limit);

      const results = keys.map(k => ({
        id: k,
        title: k,
        source: `https://polyhaven.com/a/${k}`,
        note: "Abra o link para baixar o asset/model."
      }));

      return res.json({ provider: "POLYHAVEN", query, type: assetType, results });
    }

    return res.json({ provider: "none", query, type: assetType, results: [] });
  } catch (err) {
    return res.status(500).json({ error: String(err?.message || err) });
  }
});

function stripTags(s) {
  return String(s || "")
    .replace(/<script[\s\S]*?<\/script>/gi, "")
    .replace(/<style[\s\S]*?<\/style>/gi, "")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

app.listen(PORT, () => {
  console.log(`AI Game Forge API running on http://localhost:${PORT}`);
});
